'use strict';
const { cmd } = require('../lib/registry');
const U = require('../lib/util');
const ai = require('../lib/ai');

const JOKES = ['Pourquoi les plongeurs plongent-ils toujours en arrière ? Parce que sinon ils tombent dans le bateau.', 'Que dit un escargot quand il croise une limace ? Regarde le nudiste.', 'Quel est le comble pour un électricien ? De ne pas être au courant.', 'Pourquoi le livre de maths est-il triste ? Parce qu\'il a trop de problèmes.', 'Que fait une fraise sur un cheval ? Tagada tagada.', 'Quel est le sport préféré des insectes ? Le cricket.'];
const COMPL = ['Tu as un esprit remarquablement vif.', 'Ta bonne humeur est contagieuse.', 'Tu rends les gens autour de toi meilleurs.', 'Ta curiosité est une vraie force.', 'On peut toujours compter sur toi.', 'Tu as un excellent sens de l\'humour.'];
const INSULT = ['Tu es aussi rapide qu\'une tortue sous somnifères.', 'Tu as le sens de l\'orientation d\'un GPS sans batterie.', 'Ton wifi est plus stable que tes décisions.', 'Tu es la preuve que le café ne fait pas tout.'];
const ROAST = ['Tu es le genre de personne qui arrive en retard à son propre rendez-vous.', 'Même ton ombre prend ses distances quand tu chantes.', 'Tu as déjà perdu une partie contre le bot, avoue-le.', 'Ton niveau d\'organisation est un mythe urbain.'];
const FLIRT = ['Tu crois au coup de foudre ou je dois repasser ?', 'Si tu étais un mot de passe, je ne t\'oublierais jamais.', 'Ton sourire devrait être déclaré patrimoine mondial.', 'On se connaît ? Parce que tu ressembles à mes projets du week-end.'];
const VERSES = ['Le temps passe sans bruit, mais ton nom reste écrit dans chacun de mes jours.', 'Sous la lune d\'automne, mon cœur répète ton nom comme une prière douce.', 'Entre deux silences, il y a toi, et le monde devient plus lumineux.', 'Ce que les mots ne disent pas, mes pensées te l\'envoient chaque soir.'];
const GN = ['Bonne nuit, que tes rêves soient doux et que demain soit léger.', 'Repose-toi bien, la journée de demain t\'attend avec de belles choses.', 'Ferme les yeux, respire, et laisse la nuit faire son travail.'];
const ROSE = ['Une rose pour toi : que cette journée s\'ouvre comme une fleur.', 'Pour te rappeler que tu comptes : une rose virtuelle et sincère.', 'Une rose, un sourire, et tous mes vœux de bonheur pour aujourd\'hui.'];
const ILY = ['Je t\'aime, simplement, profondément et sans condition.', 'Je t\'aime plus qu\'hier, et moins que demain.', 'Je t\'aime, et chaque jour me le confirme.'];
const QUESTIONS = ['Quel est le meilleur voyage que tu aies fait ?', 'Quelle compétence aimerais-tu maîtriser en un claquement de doigts ?', 'Quel film pourrais-tu revoir sans te lasser ?', 'Quel est ton plus beau souvenir d\'enfance ?', 'Si tu pouvais dîner avec une personne, vivante ou non, qui choisirais-tu ?'];
const TEDDY = ['Un gros câlin d\'ours en peluche pour toi, avec toute ma tendresse.', 'Joyeuse journée des peluches : tu mérites un câlin immense.', 'Un petit ours t\'envoie un message : tu es précieux.'];
const LOVE = ['Ma plus belle chance a été de te rencontrer.', 'Avec toi, même les jours gris ont des couleurs.', 'Tu es mon endroit préféré, où que je sois.', 'Merci d\'être toi, c\'est déjà un cadeau.'];
const box = (c, t, l, m) => c.reply(U.box(t, l), m);
const list = (name, title, arr) => cmd(name, {}, (c) => box(c, title, [U.pick(arr)]));
const pct = (a, b) => U.hashStr([a, b].sort().join('|')) % 101;

list('joke', 'Blague', JOKES); list('compliment', 'Compliment', COMPL); list('insult', 'Pique amicale', INSULT);
list('roast', 'Taquinerie', ROAST); list('flirt', 'Drague', FLIRT); list('shayari', 'Vers poétique', VERSES);
list('goodnight', 'Bonne nuit', GN); list('roseday', 'Une rose pour toi', ROSE); list('iloveyou', 'Déclaration', ILY);
list('question', 'Question à partager', QUESTIONS); list('teddy', 'Message tendre', TEDDY); list('lovemsg', 'Message d\'amour', LOVE);

const targetName = (c) => { const t = c.target(); return t ? { name: '@' + U.jidNum(t), jid: t } : null; };
cmd('joke2', {}, async (c) => {
  const j = await U.getJSON('https://v2.jokeapi.dev/joke/Any?safe-mode&blacklistFlags=nsfw,religious,political,racist,sexist,explicit');
  const t = j.type === 'single' ? j.joke : j.setup + '\n' + j.delivery;
  await box(c, 'Blague (traduite)', [c.S.lang === 'en' ? t : await U.translate(t, c.S.lang, 'en').catch(() => t)]);
});
cmd('fact', {}, async (c) => {
  const j = await U.getJSON('https://uselessfacts.jsph.pl/api/v2/facts/random?language=en');
  await box(c, 'Le saviez-vous', [c.S.lang === 'en' ? j.text : await U.translate(j.text, c.S.lang, 'en').catch(() => j.text)]);
});
async function quote(c) {
  const j = await U.getJSON('https://zenquotes.io/api/random');
  const q = j[0];
  await box(c, 'Citation', [c.S.lang === 'en' ? q.q : await U.translate(q.q, c.S.lang, 'en').catch(() => q.q), 'Auteur : ' + q.a]);
}
cmd('quote', {}, quote); cmd('quotes', {}, quote);
cmd('ship', { usage: 'ship @personne1 @personne2' }, async (c) => {
  const m = c.mentioned;
  if (m.length < 2) return c.usage(c.prefix + 'ship @personne1 @personne2');
  const p = pct(m[0], m[1]);
  await box(c, 'Compatibilité', ['@' + U.jidNum(m[0]) + ' et @' + U.jidNum(m[1]), 'Score : ' + p + ' %', p > 75 ? 'Excellente entente.' : p > 40 ? 'Il y a du potentiel.' : 'Ça demande des efforts.'], m.slice(0, 2));
});
function meter(name, title, salt) {
  cmd(name, { usage: name + ' [@membre]' }, async (c) => {
    const t = c.target() || c.sender;
    await box(c, title, ['@' + U.jidNum(t) + ' : ' + (U.hashStr(salt + U.jidNum(t) + U.nowParts().date) % 101) + ' %', 'Résultat humoristique, valable pour aujourd\'hui.'], [t]);
  });
}
meter('simp', 'Compteur de dévotion', 'simp'); meter('stupid', 'Compteur de distraction', 'stupid');
cmd('couplepp', {}, async (c) => {
  await c.reply('Création d\'une paire d\'avatars assortis en cours...');
  await c.sendMedia('image', await U.getBuf(ai.imageUrl('two matching couple profile picture avatars side by side, boy and girl, soft anime illustration, pastel colors', 'flux'), { timeout: 120000 }), 'Avatars de couple');
});
cmd('coffe', {}, async (c) => {
  const j = await U.getJSON('https://coffee.alexflipnote.dev/random.json');
  await c.sendMedia('image', await U.getBuf(j.file), 'Un café pour toi.');
});
module.exports = { targetName };
