'use strict';
const { cmd } = require('../lib/registry');
const cfg = require('../lib/config');
const store = require('../lib/store');
const U = require('../lib/util');
const H = require('../lib/handler');

const G = (c) => store.group(c.S, c.jid);
const pn = (p) => U.jidNum(p.phoneNumber || p.id);
const admins = (c) => c.meta.participants.filter((p) => p.admin);
const at = (p) => '@' + U.jidNum(p.id);
const stateTxt = (v) => (v ? 'activé' : 'désactivé');
const isBot = (c, jid) => H.botIds(c.entry).has(U.jidNum(jid));
const chunk = (a, n) => { const o = []; for (let i = 0; i < a.length; i += n) o.push(a.slice(i, i + n)); return o; };
const MOD = { level: 'admin', group: true, botAdmin: true };
const ADM = { level: 'admin', group: true };

// ---- Membres ----
cmd('add', { ...MOD, usage: 'add <numéro>' }, async (c) => {
  const nums = c.args.map((a) => a.replace(/\D/g, '')).filter((a) => a.length >= 8);
  if (!nums.length) return c.usage(c.prefix + 'add <numéro international sans +>');
  const res = await c.sock.groupParticipantsUpdate(c.jid, nums.map(U.toJid), 'add');
  await c.reply(U.box('Ajout de membres', res.map((r, i) => '+' + nums[i] + ' : ' + (String(r.status) === '200' ? 'ajouté' : String(r.status) === '403' ? 'invitation envoyée ou confidentialité restrictive' : 'échec (code ' + r.status + ')'))));
});
cmd('kick', { ...MOD, usage: 'kick @membre' }, async (c) => {
  const t = c.target();
  if (!t) return c.usage(c.prefix + 'kick @membre (ou en répondant à son message)');
  if (isBot(c, t)) return c.reply('Je ne peux pas m\'expulser moi-même. Utilise ' + c.prefix + 'leavegc.');
  await c.sock.groupParticipantsUpdate(c.jid, [t], 'remove');
  await c.reply('@' + U.jidNum(t) + ' a été expulsé du groupe.', [t]);
});
cmd('kickall', { ...MOD, level: 'owner', usage: 'kickall confirm' }, async (c) => {
  const list = c.meta.participants.filter((p) => !p.admin && !isBot(c, p.id));
  if ((c.args[0] || '').toLowerCase() !== 'confirm') return c.reply(U.box('Confirmation requise', ['Cette commande expulse ' + list.length + ' membre(s) non administrateur(s).', 'Pour confirmer : ' + c.prefix + 'kickall confirm']));
  await c.reply('Expulsion de ' + list.length + ' membre(s) en cours...');
  let n = 0;
  for (const part of chunk(list.map((p) => p.id), 5)) {
    try { await c.sock.groupParticipantsUpdate(c.jid, part, 'remove'); n += part.length; } catch (e) { /* continue */ }
    await U.sleep(1500);
  }
  await c.reply('Terminé : ' + n + ' membre(s) expulsé(s).');
});
async function setRole(c, action) {
  const t = c.target();
  if (!t) return c.usage(c.prefix + c.cmd + ' @membre');
  await c.sock.groupParticipantsUpdate(c.jid, [t], action);
  await c.reply('@' + U.jidNum(t) + (action === 'promote' ? ' est maintenant administrateur.' : ' n\'est plus administrateur.'), [t]);
}
cmd('promote', { ...MOD, usage: 'promote @membre' }, (c) => setRole(c, 'promote'));
cmd('demote', { ...MOD, usage: 'demote @membre' }, (c) => setRole(c, 'demote'));

// ---- Reglages du groupe ----
cmd('mute', { ...MOD }, async (c) => { await c.sock.groupSettingUpdate(c.jid, 'announcement'); await c.reply('Groupe fermé : seuls les administrateurs peuvent écrire.'); });
cmd('unmute', { ...MOD }, async (c) => { await c.sock.groupSettingUpdate(c.jid, 'not_announcement'); await c.reply('Groupe ouvert : tous les membres peuvent écrire.'); });
cmd('lockgroup', { ...MOD }, async (c) => { await c.sock.groupSettingUpdate(c.jid, 'locked'); await c.reply('Informations du groupe verrouillées : seuls les administrateurs peuvent les modifier.'); });
cmd('unlockgroup', { ...MOD }, async (c) => { await c.sock.groupSettingUpdate(c.jid, 'unlocked'); await c.reply('Informations du groupe déverrouillées : tous les membres peuvent les modifier.'); });
cmd('revoke', { ...MOD }, async (c) => {
  const code = await c.sock.groupRevokeInvite(c.jid);
  await c.reply(U.box('Nouveau lien d\'invitation', ['https://chat.whatsapp.com/' + code, 'L\'ancien lien ne fonctionne plus.']));
});
cmd('grouplink', { ...MOD }, async (c) => {
  const code = await c.sock.groupInviteCode(c.jid);
  await c.reply(U.box('Lien d\'invitation', ['https://chat.whatsapp.com/' + code]));
});
cmd('setname', { ...MOD, usage: 'setname <nouveau nom>' }, async (c) => {
  if (!c.text) return c.usage(c.prefix + 'setname <nouveau nom>');
  await c.sock.groupUpdateSubject(c.jid, c.text.slice(0, 100));
  await c.reply('Nom du groupe modifié.');
});
cmd('setdesc', { ...MOD, usage: 'setdesc <description>' }, async (c) => {
  if (!c.text) return c.usage(c.prefix + 'setdesc <description>');
  await c.sock.groupUpdateDescription(c.jid, c.text);
  await c.reply('Description du groupe modifiée.');
});
cmd('setgcpp', { ...MOD, usage: 'setgcpp (en répondant à une image)' }, async (c) => {
  const md = await c.media(['image']);
  if (!md) return c.reply('Envoie ou cite une image avec ' + c.prefix + 'setgcpp.');
  await c.sock.updateProfilePicture(c.jid, md.buffer);
  await c.reply('Photo du groupe modifiée.');
});
cmd('fullgroupphoto', { ...ADM }, async (c) => {
  let url;
  try { url = await c.sock.profilePictureUrl(c.jid, 'image'); } catch (e) { return c.reply('Ce groupe n\'a pas de photo.'); }
  await c.sendMedia('image', await U.getBuf(url), 'Photo du groupe : ' + c.meta.subject);
});
cmd('gcset', { ...MOD, usage: 'gcset <open|close|lock|unlock|approve on/off|addmode admin/all|ephemeral off/24h/7d/90d>' }, async (c) => {
  const a = (c.args[0] || '').toLowerCase(), b = (c.args[1] || '').toLowerCase();
  const done = (t) => c.reply('Réglage appliqué : ' + t);
  if (a === 'open') { await c.sock.groupSettingUpdate(c.jid, 'not_announcement'); return done('groupe ouvert'); }
  if (a === 'close') { await c.sock.groupSettingUpdate(c.jid, 'announcement'); return done('groupe fermé'); }
  if (a === 'lock') { await c.sock.groupSettingUpdate(c.jid, 'locked'); return done('infos verrouillées'); }
  if (a === 'unlock') { await c.sock.groupSettingUpdate(c.jid, 'unlocked'); return done('infos déverrouillées'); }
  if (a === 'approve' && ['on', 'off'].includes(b)) { await c.sock.groupJoinApprovalMode(c.jid, b); return done('approbation des demandes ' + b); }
  if (a === 'addmode' && ['admin', 'all'].includes(b)) { await c.sock.groupMemberAddMode(c.jid, b === 'admin' ? 'admin_add' : 'all_member_add'); return done('ajout de membres : ' + (b === 'admin' ? 'administrateurs' : 'tous')); }
  if (a === 'ephemeral' && ['off', '24h', '7d', '90d'].includes(b)) { await c.sock.groupToggleEphemeral(c.jid, { off: 0, '24h': 86400, '7d': 604800, '90d': 7776000 }[b]); return done('messages éphémères : ' + b); }
  await c.reply(U.box('Réglages rapides du groupe', [
    c.prefix + 'gcset open / close : ouvrir ou fermer le chat', c.prefix + 'gcset lock / unlock : infos du groupe',
    c.prefix + 'gcset approve on / off : approbation des demandes', c.prefix + 'gcset addmode admin / all : qui peut ajouter',
    c.prefix + 'gcset ephemeral off / 24h / 7d / 90d : messages éphémères']));
});
cmd('gcstatus', { ...ADM }, async (c) => {
  const g = G(c);
  const f = g.f || {};
  await c.reply(U.box('Statut du groupe : ' + c.meta.subject, [
    'Chat : ' + (c.meta.announce ? 'fermé (admins uniquement)' : 'ouvert'),
    'Infos du groupe : ' + (c.meta.restrict ? 'verrouillées' : 'modifiables par tous'),
    'Approbation des demandes : ' + stateTxt(c.meta.joinApprovalMode),
    'Messages éphémères : ' + (c.meta.ephemeralDuration ? c.meta.ephemeralDuration + ' s' : 'désactivés'),
    'Antilink : ' + (f.antilink && f.antilink !== 'off' ? f.antilink : 'désactivé'),
    'Antitag : ' + stateTxt(f.antitag), 'Antibot : ' + stateTxt(f.antibot), 'Antibadword : ' + stateTxt(f.antibadword),
    'Antifakenumber : ' + stateTxt(f.antifakenumber), 'Antigroupmention : ' + stateTxt(f.antigroupmention), 'Antigroupstatus : ' + stateTxt(f.antigroupstatus),
    'Alertes admin : ' + stateTxt(f.adminalerts), 'Bienvenue : ' + stateTxt(g.welcome.on), 'Au revoir : ' + stateTxt(g.goodbye.on),
    'Mode lent : ' + (g.slow ? g.slow + ' s' : 'désactivé'),
  ]));
});
cmd('newgroup', { level: 'owner', usage: 'newgroup <nom>' }, async (c) => {
  if (!c.text) return c.usage(c.prefix + 'newgroup <nom du groupe>');
  const g = await c.sock.groupCreate(c.text.slice(0, 100), [c.sender]);
  await c.reply(U.box('Groupe créé', ['Nom : ' + g.subject, 'ID : ' + g.id]));
});
cmd('leavegc', { level: 'owner', group: true }, async (c) => {
  await c.reply('Le bot quitte le groupe.');
  await c.sock.groupLeave(c.jid);
});
cmd('groupinfo', { ...ADM }, async (c) => {
  const m = c.meta;
  await c.reply(U.box('Informations du groupe', [
    'Nom : ' + m.subject, 'ID : ' + m.id, 'Membres : ' + m.participants.length, 'Administrateurs : ' + admins(c).length,
    'Créé le : ' + (m.creation ? new Date(m.creation * 1000).toLocaleDateString('fr-FR', { timeZone: cfg.TZ }) : 'inconnu'),
    'Chat : ' + (m.announce ? 'fermé' : 'ouvert'), 'Description : ' + (m.desc || 'aucune'),
  ]));
});
cmd('staff', { ...ADM }, async (c) => {
  const a = admins(c);
  await c.reply(U.box('Administrateurs (' + a.length + ')', a.map((p, i) => (i + 1) + '. ' + at(p) + (p.admin === 'superadmin' ? ' (créateur)' : ''))), a.map((p) => p.id));
});
cmd('jid', {}, async (c) => { await c.reply(U.box('Identifiant', ['Discussion : ' + c.jid, 'Expéditeur : ' + c.sender])); });
cmd('linkinfo', { ...ADM, usage: 'linkinfo <lien du groupe>' }, async (c) => {
  const m = c.text.match(/chat\.whatsapp\.com\/([A-Za-z0-9]+)/);
  if (!m) return c.usage(c.prefix + 'linkinfo https://chat.whatsapp.com/xxxx');
  const i = await c.sock.groupGetInviteInfo(m[1]);
  await c.reply(U.box('Informations du lien', ['Nom : ' + i.subject, 'ID : ' + i.id, 'Membres : ' + (i.size || i.participants.length), 'Description : ' + (i.desc || 'aucune')]));
});

// ---- Tags ----
cmd('tagall', { ...ADM, usage: 'tagall [message]' }, async (c) => {
  const ps = c.meta.participants;
  await c.reply(U.box('Annonce' + (c.text ? ' : ' + c.text : ''), ps.map((p, i) => (i + 1) + '. ' + at(p))), ps.map((p) => p.id));
});
cmd('tag', { ...ADM, usage: 'tag <message>' }, async (c) => {
  if (!c.text) return c.usage(c.prefix + 'tag <message>');
  await c.reply(U.box('Message pour tous les membres', [c.text]), c.meta.participants.map((p) => p.id));
});
cmd('hidetag', { ...ADM, usage: 'hidetag <message> (ou en répondant à un message)' }, async (c) => {
  const mentions = c.meta.participants.map((p) => p.id);
  const md = c.quoted ? await c.media() : null;
  if (md && ['image', 'video', 'audio', 'document'].includes(md.type)) {
    const extra = { mentions };
    if (md.type === 'audio') extra.mimetype = md.mime || 'audio/mp4';
    if (md.type === 'document') { extra.mimetype = md.mime; extra.fileName = md.content.fileName || 'fichier'; }
    return c.entry.media(c.jid, md.type, md.buffer, c.text || (md.content.caption || ''), { extra });
  }
  const text = c.text || (c.quoted && (c.quoted.message.conversation || (c.quoted.message.extendedTextMessage && c.quoted.message.extendedTextMessage.text))) || '';
  if (!text) return c.usage(c.prefix + 'hidetag <message>');
  await c.reply(text, mentions);
});
cmd('tagadmins', { ...ADM, usage: 'tagadmins [message]' }, async (c) => {
  const a = admins(c);
  await c.reply(U.box('Appel aux administrateurs' + (c.text ? ' : ' + c.text : ''), a.map((p, i) => (i + 1) + '. ' + at(p))), a.map((p) => p.id));
});
cmd('tagnotadmin', { ...ADM, usage: 'tagnotadmin [message]' }, async (c) => {
  const a = c.meta.participants.filter((p) => !p.admin);
  await c.reply(U.box('Appel aux membres' + (c.text ? ' : ' + c.text : ''), a.map((p, i) => (i + 1) + '. ' + at(p))), a.map((p) => p.id));
});

// ---- Presence ----
async function scan(c) {
  const ps = c.meta.participants.slice(0, 250);
  try { await c.sock.sendPresenceUpdate('available', c.jid); } catch (e) { /* ignore */ }
  for (const p of ps) { c.sock.presenceSubscribe(p.id).catch(() => {}); await U.sleep(25); }
  await U.sleep(5000);
  return ps.map((p) => {
    const pr = c.entry.presence[p.id];
    const v = pr && Object.values(pr)[0];
    const st = v && v.lastKnownPresence;
    return { p, online: ['available', 'composing', 'recording'].includes(st), st };
  });
}
const NOTE = 'Les membres qui masquent leur présence en ligne n\'apparaissent pas.';
cmd('online', { ...ADM }, async (c) => {
  const r = (await scan(c)).filter((x) => x.online);
  await c.reply(U.box('Membres en ligne (' + r.length + ')', [...r.map((x, i) => (i + 1) + '. ' + at(x.p)), NOTE]), r.map((x) => x.p.id));
});
cmd('onlineusers', { ...ADM }, async (c) => {
  const r = (await scan(c)).filter((x) => x.online && !x.p.admin);
  const label = { available: 'en ligne', composing: 'écrit', recording: 'enregistre' };
  await c.reply(U.box('Membres en ligne - détail (' + r.length + ')', [...r.map((x, i) => (i + 1) + '. ' + at(x.p) + ' : ' + label[x.st]), NOTE]), r.map((x) => x.p.id));
});
cmd('onlineadmins', { ...ADM }, async (c) => {
  const r = (await scan(c)).filter((x) => x.online && x.p.admin);
  await c.reply(U.box('Administrateurs en ligne (' + r.length + ')', [...r.map((x, i) => (i + 1) + '. ' + at(x.p)), NOTE]), r.map((x) => x.p.id));
});
cmd('onlinestats', { ...ADM }, async (c) => {
  const all = await scan(c);
  const on = all.filter((x) => x.online);
  await c.reply(U.box('Statistiques de présence', [
    'Membres analysés : ' + all.length, 'En ligne : ' + on.length + ' (' + (all.length ? Math.round(on.length * 100 / all.length) : 0) + ' %)',
    'Administrateurs en ligne : ' + on.filter((x) => x.p.admin).length, 'Membres en ligne : ' + on.filter((x) => !x.p.admin).length, NOTE]));
});

// ---- Accueil, regles ----
function greet(name, label, defText) {
  cmd(name, { ...ADM, usage: name + ' <on|off|set <texte>>' }, async (c) => {
    const g = G(c), o = g[name];
    const sub = (c.args[0] || '').toLowerCase();
    if (sub === 'set') {
      const t = c.args.slice(1).join(' ');
      if (!t) return c.usage(c.prefix + name + ' set <texte> (variables : @user, {group}, {count})');
      o.text = t; o.on = true; c.S.save();
      return c.reply(label + ' : activé avec le nouveau texte.');
    }
    const v = U.onoff(sub);
    if (v === null) return c.reply(U.box(label, ['État : ' + stateTxt(o.on), 'Texte : ' + (o.text || defText), 'Utilisation : ' + c.prefix + name + ' <on|off|set <texte>>', 'Variables : @user, {group}, {count}']));
    o.on = v; c.S.save();
    await c.reply(label + ' : ' + stateTxt(v));
  });
}
greet('welcome', 'Message de bienvenue', 'Bienvenue @user dans {group}.');
greet('goodbye', 'Message d\'au revoir', 'Au revoir @user.');
cmd('rules', { group: true, usage: 'rules | rules set <texte> | rules del' }, async (c) => {
  const g = G(c);
  const sub = (c.args[0] || '').toLowerCase();
  if (sub === 'set' || sub === 'del') {
    if (!(c.isOwner || c.isAdmin)) return c.reply(c.t('err_admin'));
    g.rules = sub === 'del' ? '' : c.args.slice(1).join(' ').replace(/\\n/g, '\n');
    if (sub === 'set' && !g.rules) return c.usage(c.prefix + 'rules set <texte du règlement>');
    c.S.save();
    return c.reply(sub === 'del' ? 'Règlement supprimé.' : 'Règlement enregistré.');
  }
  await c.reply(U.box('Règlement du groupe', [g.rules || 'Aucun règlement défini. Un administrateur peut en créer un avec ' + c.prefix + 'rules set <texte>.']));
});

// ---- Divers ----
cmd('poll', { ...ADM, usage: 'poll <question> | <option 1> | <option 2> ...' }, async (c) => {
  const parts = c.text.split('|').map((s) => s.trim()).filter(Boolean);
  if (parts.length < 3) return c.usage(c.prefix + 'poll <question> | <option 1> | <option 2> ...');
  await c.send({ poll: { name: parts[0].slice(0, 200), values: [...new Set(parts.slice(1, 13))], selectableCount: 1 } });
  await c.reply('Sondage créé. Vote en sélectionnant une option.');
});
cmd('afk', { usage: 'afk [raison]' }, async (c) => {
  c.S.afk[c.num] = { at: Date.now(), reason: c.text };
  c.S.save();
  await c.reply('@' + c.num + ' est maintenant absent.\nMotif : ' + (c.text || 'non précisé') + '\nLe mode absent se désactive dès ton prochain message.', [c.sender]);
});
cmd('couple', { ...ADM }, async (c) => {
  const ps = c.meta.participants.filter((p) => !isBot(c, p.id));
  if (ps.length < 2) return c.reply('Il faut au moins 2 membres.');
  const a = U.pick(ps);
  const b = U.pick(ps.filter((p) => p.id !== a.id));
  await c.reply(U.box('Couple du jour', [at(a) + ' et ' + at(b), 'Compatibilité : ' + U.rand(40, 100) + ' %']), [a.id, b.id]);
});

// ---- Protections ----
function feat(name, label, modes) {
  cmd(name, { ...ADM, usage: name + (modes ? ' <' + modes.join('|') + '>' : ' <on|off>') }, async (c) => {
    const g = G(c);
    g.f = g.f || {};
    const a = (c.args[0] || '').toLowerCase();
    const cur = g.f[name];
    const curTxt = modes ? (cur && cur !== 'off' ? cur : 'désactivé') : stateTxt(cur);
    if (!a) return c.reply(U.box(label, ['État : ' + curTxt, 'Utilisation : ' + c.prefix + name + (modes ? ' <' + modes.join('|') + '>' : ' <on|off>'), c.botAdmin ? null : 'Attention : le bot doit être administrateur pour appliquer les sanctions.']));
    if (modes) {
      const v = a === 'on' ? 'delete' : a;
      if (!modes.includes(v)) return c.usage(c.prefix + name + ' <' + modes.join('|') + '>');
      g.f[name] = v;
      c.S.save();
      return c.reply(label + ' : ' + (v === 'off' ? 'désactivé' : 'activé (action : ' + v + ')') + (c.botAdmin ? '' : '\nAttention : le bot doit être administrateur pour appliquer les sanctions.'));
    }
    const v = U.onoff(a);
    if (v === null) return c.usage(c.prefix + name + ' <on|off>');
    g.f[name] = v; c.S.save();
    await c.reply(label + ' : ' + stateTxt(v) + (v && !c.botAdmin && name !== 'adminalerts' ? '\nAttention : le bot doit être administrateur pour appliquer les sanctions.' : ''));
  });
}
feat('antilink', 'Anti-liens', ['off', 'delete', 'warn', 'kick']);
feat('antitag', 'Anti-mentions en masse');
feat('antigroupmention', 'Anti-mention de groupe');
feat('antigroupstatus', 'Anti-partage de statut en groupe');
feat('antibot', 'Anti-bots');
feat('adminalerts', 'Alertes de changement d\'administrateur');

// Listes de mots : antibadword (liste du groupe), antiword
function wordList(name, label, key, hasToggle) {
  cmd(name, { ...ADM, usage: name + ' <' + (hasToggle ? 'on|off|' : '') + 'add <mot>|del <mot>|list>' }, async (c) => {
    const g = G(c);
    g.f = g.f || {};
    const sub = (c.args[0] || '').toLowerCase();
    const w = c.args.slice(1).join(' ').toLowerCase();
    g[key] = g[key] || [];
    if (sub === 'add' && w) { if (!g[key].includes(w)) g[key].push(w); c.S.save(); return c.reply('Mot ajouté : ' + w); }
    if (sub === 'del' && w) { g[key] = g[key].filter((x) => x !== w); c.S.save(); return c.reply('Mot retiré : ' + w); }
    if (sub === 'list') return c.reply(U.box(label + ' - mots personnalisés', g[key].length ? g[key].map((x, i) => (i + 1) + '. ' + x) : ['Aucun mot.']));
    if (hasToggle) {
      const v = U.onoff(sub);
      if (v !== null) { g.f[name] = v; c.S.save(); return c.reply(label + ' : ' + stateTxt(v) + (v && !c.botAdmin ? '\nAttention : le bot doit être administrateur pour appliquer les sanctions.' : '')); }
    }
    await c.reply(U.box(label, [hasToggle ? 'État : ' + stateTxt(g.f[name]) : null, 'Utilisation : ' + c.prefix + name + ' ' + (hasToggle ? '<on|off> | ' : '') + 'add <mot> | del <mot> | list']));
  });
}
wordList('antibadword', 'Filtre d\'insultes', 'badwords', true);
wordList('antiword', 'Filtre de mots personnalisés', 'words', false);

cmd('antifakenumber', { ...ADM, usage: 'antifakenumber <on|off|add <préfixe>|del <préfixe>|list>' }, async (c) => {
  const g = G(c);
  g.f = g.f || {};
  const sub = (c.args[0] || '').toLowerCase();
  const p = (c.args[1] || '').replace(/\D/g, '');
  if (sub === 'add' && p) { if (!g.fakeprefix.includes(p)) g.fakeprefix.push(p); c.S.save(); return c.reply('Indicatif bloqué : +' + p); }
  if (sub === 'del' && p) { g.fakeprefix = g.fakeprefix.filter((x) => x !== p); c.S.save(); return c.reply('Indicatif retiré : +' + p); }
  if (sub === 'list') return c.reply(U.box('Indicatifs bloqués', g.fakeprefix.length ? g.fakeprefix.map((x) => '+' + x) : ['Aucun indicatif défini.']));
  const v = U.onoff(sub);
  if (v === null) return c.reply(U.box('Anti-faux-numéros', ['État : ' + stateTxt(g.f.antifakenumber), 'Indicatifs bloqués : ' + (g.fakeprefix.map((x) => '+' + x).join(', ') || 'aucun'), 'Utilisation : ' + c.prefix + 'antifakenumber <on|off> | add <indicatif> | del <indicatif> | list', 'Exemple : ' + c.prefix + 'antifakenumber add 1']));
  g.f.antifakenumber = v; c.S.save();
  await c.reply('Anti-faux-numéros : ' + stateTxt(v) + (v && !g.fakeprefix.length ? '\nAucun indicatif n\'est encore bloqué. Ajoute-en avec ' + c.prefix + 'antifakenumber add <indicatif>.' : ''));
});
cmd('slowmode', { ...ADM, usage: 'slowmode <secondes|off>' }, async (c) => {
  const g = G(c);
  const a = (c.args[0] || '').toLowerCase();
  if (a === 'off') { g.slow = 0; c.S.save(); return c.reply('Mode lent désactivé.'); }
  const n = parseInt(a, 10);
  if (!n || n < 1 || n > 3600) return c.reply(U.box('Mode lent', ['État : ' + (g.slow ? g.slow + ' s entre deux messages' : 'désactivé'), 'Utilisation : ' + c.prefix + 'slowmode <1 à 3600 secondes|off>']));
  g.slow = n; c.S.save();
  await c.reply('Mode lent activé : un message toutes les ' + n + ' secondes par membre (hors administrateurs).');
});

const FEATURES = ['antilink', 'antitag', 'antigroupmention', 'antigroupstatus', 'antibot', 'antibadword', 'antifakenumber', 'adminalerts', 'welcome', 'goodbye'];
async function enableDisable(c, on) {
  const f = (c.args[0] || '').toLowerCase();
  if (!FEATURES.includes(f)) return c.reply(U.box('Fonctions disponibles', [...FEATURES, 'Utilisation : ' + c.prefix + c.cmd + ' <fonction>']));
  const g = G(c);
  g.f = g.f || {};
  if (f === 'welcome' || f === 'goodbye') g[f].on = on;
  else if (f === 'antilink') g.f.antilink = on ? 'delete' : 'off';
  else g.f[f] = on;
  c.S.save();
  await c.reply('Fonction ' + f + ' : ' + stateTxt(on));
}
cmd('enable', { ...ADM, usage: 'enable <fonction>' }, (c) => enableDisable(c, true));
cmd('disable', { ...ADM, usage: 'disable <fonction>' }, (c) => enableDisable(c, false));

// ---- Avertissements ----
const WARN_LIMIT = 3;
cmd('warn', { ...ADM, usage: 'warn @membre [raison]' }, async (c) => {
  const t = c.target();
  if (!t) return c.usage(c.prefix + 'warn @membre [raison]');
  const n = U.jidNum(t), g = G(c);
  g.warns[n] = (g.warns[n] || 0) + 1;
  const w = g.warns[n];
  c.S.save();
  if (w >= WARN_LIMIT && c.botAdmin) {
    g.warns[n] = 0; c.S.save();
    try { await c.sock.groupParticipantsUpdate(c.jid, [t], 'remove'); } catch (e) { /* ignore */ }
    return c.reply('@' + n + ' a atteint ' + WARN_LIMIT + ' avertissements et a été expulsé.', [t]);
  }
  await c.reply('@' + n + ' avertissement ' + w + '/' + WARN_LIMIT + (c.text ? '\nRaison : ' + c.args.filter((a) => !a.startsWith('@')).join(' ') : ''), [t]);
});
cmd('warnings', { ...ADM }, async (c) => {
  const g = G(c);
  const l = Object.entries(g.warns).filter(([, v]) => v > 0);
  await c.reply(U.box('Avertissements du groupe', l.length ? l.map(([k, v], i) => (i + 1) + '. @' + k + ' : ' + v + '/' + WARN_LIMIT) : ['Aucun avertissement.']), l.map(([k]) => U.toJid(k)));
});
cmd('checkwarn', { ...ADM, usage: 'checkwarn @membre' }, async (c) => {
  const t = c.target();
  if (!t) return c.usage(c.prefix + 'checkwarn @membre');
  await c.reply('@' + U.jidNum(t) + ' : ' + (G(c).warns[U.jidNum(t)] || 0) + '/' + WARN_LIMIT + ' avertissement(s).', [t]);
});
cmd('resetwarn', { ...ADM, usage: 'resetwarn @membre | all' }, async (c) => {
  const g = G(c);
  if ((c.args[0] || '').toLowerCase() === 'all') { g.warns = {}; c.S.save(); return c.reply('Tous les avertissements du groupe ont été réinitialisés.'); }
  const t = c.target();
  if (!t) return c.usage(c.prefix + 'resetwarn @membre | all');
  g.warns[U.jidNum(t)] = 0; c.S.save();
  await c.reply('Avertissements de @' + U.jidNum(t) + ' réinitialisés.', [t]);
});

// ---- Programmation quotidienne ----
function lockJob(name, type) {
  cmd(name, { ...ADM, usage: name + ' <HH:MM>' }, async (c) => {
    const hh = U.parseHHMM(c.args[0]);
    if (!hh) return c.usage(c.prefix + name + ' <HH:MM> (heure de ' + cfg.TZ + ', répétée chaque jour)');
    c.S.jobs = c.S.jobs.filter((j) => !(j.type === type && j.jid === c.jid));
    c.S.jobs.push({ id: Date.now().toString(36), type, jid: c.jid, hhmm: hh });
    c.S.save();
    await c.reply((type === 'lock' ? 'Fermeture' : 'Ouverture') + ' automatique du groupe programmée chaque jour à ' + hh + ' (' + cfg.TZ + ').\nAnnulation : ' + c.prefix + (type === 'lock' ? 'cancellock' : 'cancelunlock'));
  });
}
lockJob('lockat', 'lock');
lockJob('unlockat', 'unlock');
function cancelJob(name, type) {
  cmd(name, { ...ADM }, async (c) => {
    const n = c.S.jobs.length;
    c.S.jobs = c.S.jobs.filter((j) => !(j.type === type && j.jid === c.jid));
    c.S.save();
    await c.reply(n === c.S.jobs.length ? 'Aucune programmation à annuler dans ce groupe.' : 'Programmation annulée.');
  });
}
cancelJob('cancellock', 'lock');
cancelJob('cancelunlock', 'unlock');

// ---- Demandes d'adhesion ----
cmd('listrequest', { ...MOD }, async (c) => {
  const l = await c.sock.groupRequestParticipantsList(c.jid);
  await c.reply(U.box('Demandes en attente (' + l.length + ')', l.length ? l.slice(0, 50).map((x, i) => (i + 1) + '. +' + U.jidNum(x.phone_number || x.jid)) : ['Aucune demande.']));
});
async function bulkRequests(c, action) {
  const l = await c.sock.groupRequestParticipantsList(c.jid);
  if (!l.length) return c.reply('Aucune demande en attente.');
  for (const part of chunk(l.map((x) => x.jid), 20)) { await c.sock.groupRequestParticipantsUpdate(c.jid, part, action); await U.sleep(1000); }
  await c.reply(l.length + ' demande(s) ' + (action === 'approve' ? 'acceptée(s).' : 'rejetée(s).'));
}
cmd('acceptall', { ...MOD }, (c) => bulkRequests(c, 'approve'));
cmd('rejectall', { ...MOD }, (c) => bulkRequests(c, 'reject'));
