'use strict';
const path = require('path');
const express = require('express');
const cfg = require('./lib/config');
const manager = require('./lib/session');
const store = require('./lib/store');
const U = require('./lib/util');
require('./commands');

process.on('unhandledRejection', (e) => console.error('[unhandledRejection]', e && e.message ? e.message : e));
process.on('uncaughtException', (e) => console.error('[uncaughtException]', e && e.message ? e.message : e));

const app = express();
app.set('trust proxy', 1);
app.use(express.json({ limit: '10kb' }));
app.use(express.static(path.join(cfg.ROOT, 'public')));

app.get('/health', (req, res) => res.type('text/plain').send('ok'));
app.get('/api/status', (req, res) => res.json({ name: cfg.NAME, version: cfg.VERSION, ...manager.stats() }));

// Limitation : 5 demandes par heure et par IP, 2 appairages simultanes
const hits = new Map();
let inflight = 0;
app.post('/api/pair', async (req, res) => {
  const ip = req.ip || 'x';
  const now = Date.now();
  const list = (hits.get(ip) || []).filter((t) => now - t < 3600000);
  if (list.length >= 5) return res.status(429).json({ error: 'Trop de demandes. Réessaie dans une heure.' });
  if (inflight >= 2) return res.status(429).json({ error: 'Serveur occupé, réessaie dans une minute.' });
  list.push(now); hits.set(ip, list);
  inflight++;
  try {
    const code = await manager.pair(req.body && req.body.number);
    res.json({ code: code.match(/.{1,4}/g).join('-') });
  } catch (e) {
    res.status(400).json({ error: e.message });
  } finally { inflight--; }
});

(async () => {
  await manager.init();
  app.listen(cfg.PORT, () => console.log('[web] http://localhost:' + cfg.PORT));
  await manager.bootAll();

  // Premier demarrage : appairage automatique du numero proprietaire
  if (cfg.OWNER_NUMBER && !(await store.get('linked:' + cfg.OWNER_NUMBER, false))) {
    try {
      const code = await manager.pair(cfg.OWNER_NUMBER);
      console.log('\n==============================================');
      console.log(' CODE D\'APPAIRAGE pour +' + cfg.OWNER_NUMBER + ' : ' + code.match(/.{1,4}/g).join('-'));
      console.log(' WhatsApp > Appareils connectés > Connecter un appareil');
      console.log(' > Lier avec un numéro de téléphone > saisir le code');
      console.log('==============================================\n');
    } catch (e) { console.error('[pair auto]', e.message); }
  }
  if (cfg.PUBLIC_URL) setInterval(() => { fetch(cfg.PUBLIC_URL + '/health').catch(() => {}); }, 10 * 60 * 1000);
})().catch((e) => { console.error('[fatal]', e); process.exit(1); });

const bye = async () => { try { await store.flushAll(); } catch (e) { /* ignore */ } process.exit(0); };
process.on('SIGTERM', bye);
process.on('SIGINT', bye);
