'use strict';
const { cmd, hooks } = require('../lib/registry');
const U = require('../lib/util');

const games = new Map(); // cle : jid de la discussion
const WORDS = ['voiture', 'maison', 'bateau', 'avion', 'jardin', 'fenetre', 'chocolat', 'ordinateur', 'telephone', 'montagne', 'oiseau', 'musique', 'plage', 'lumiere', 'cuisine', 'sourire', 'horloge', 'bouteille', 'papillon', 'parapluie', 'etoile', 'nuage', 'riviere', 'village', 'tableau'];
const W5 = ['livre', 'plage', 'arbre', 'rouge', 'blanc', 'noire', 'verte', 'pomme', 'fleur', 'table', 'chien', 'chaud', 'tigre', 'monde', 'ligne', 'nuage', 'sable', 'train', 'avion', 'ville'];
const TRUTH = ['Quel est ton plus grand regret ?', 'Quelle est ta plus grosse honte ?', 'Quel est le dernier mensonge que tu as dit ?', 'Quelle habitude as-tu que tu caches aux autres ?', 'Qui, dans ce groupe, apprécies-tu le plus et pourquoi ?', 'Quel est ton plus grand rêve ?', 'Quelle est la chose la plus bizarre que tu aies déjà mangée ?'];
const DARE = ['Envoie un message vocal en chantant une chanson.', 'Change ta photo de profil pendant une heure avec une image choisie par le groupe.', 'Écris un compliment sincère à chaque membre qui est en ligne.', 'Raconte une blague au groupe.', 'Envoie ton dernier selfie.', 'Parle uniquement en rimes pendant 5 messages.'];
const WYR = ['Voyager dans le passé ou dans le futur ?', 'Être invisible ou pouvoir voler ?', 'Ne plus jamais utiliser ton téléphone ou ne plus jamais regarder la télévision ?', 'Vivre au bord de la mer ou à la montagne ?', 'Avoir un million d\'euros maintenant ou 1 000 euros par jour à vie ?', 'Toujours avoir chaud ou toujours avoir froid ?'];
const RIDDLES = [['Plus on en prend, plus on en laisse derrière soi. Qu\'est-ce que c\'est ?', 'les pas'], ['Je suis plein de trous mais je retiens l\'eau. Qui suis-je ?', 'une éponge'], ['Qu\'est-ce qui a des clés mais n\'ouvre aucune porte ?', 'un piano'], ['Qu\'est-ce qui monte mais ne redescend jamais ?', 'l\'âge'], ['J\'ai des villes mais pas de maisons, des montagnes mais pas d\'arbres, de l\'eau mais pas de poissons. Qui suis-je ?', 'une carte'], ['Qu\'est-ce qui appartient à toi mais que les autres utilisent plus que toi ?', 'ton prénom']];
const BALL = ['Oui, absolument.', 'C\'est certain.', 'Probablement oui.', 'Les signes disent oui.', 'Réponse floue, réessaie.', 'Demande plus tard.', 'Je ne peux pas le prédire maintenant.', 'Ne compte pas dessus.', 'Ma réponse est non.', 'Très peu probable.'];
const strip = (s) => s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9 ]/g, '').trim();
const say = (c, title, lines, m) => c.reply(U.box(title, lines), m);

cmd('trivia', { usage: 'trivia' }, async (c) => {
  const j = await U.getJSON('https://opentdb.com/api.php?amount=1&type=multiple&encode=url3986');
  const q = j.results[0], d = decodeURIComponent;
  const opts = [...q.incorrect_answers, q.correct_answer].map(d).sort(() => Math.random() - 0.5);
  const right = d(q.correct_answer);
  games.set(c.jid, { type: 'trivia', answer: opts.indexOf(right), text: right, until: Date.now() + 60000 });
  await say(c, 'Question de culture générale (en anglais)', [d(q.question), ...opts.map((o, i) => 'ABCD'[i] + '. ' + o), 'Réponds avec la lettre A, B, C ou D (60 secondes).']);
});
cmd('scramble', { usage: 'scramble' }, async (c) => {
  const w = U.pick(WORDS);
  let s = w;
  while (s === w) s = [...w].sort(() => Math.random() - 0.5).join('');
  games.set(c.jid, { type: 'scramble', answer: w, until: Date.now() + 90000 });
  await say(c, 'Mot mélangé', ['Remets les lettres dans l\'ordre : ' + s.toUpperCase(), 'Envoie ta réponse dans le chat (90 secondes).']);
});
cmd('wordle', { usage: 'wordle' }, async (c) => {
  games.set(c.jid, { type: 'wordle', answer: U.pick(W5), tries: [], until: Date.now() + 600000 });
  await say(c, 'Wordle', ['Devine le mot de 5 lettres en 6 essais.', 'Envoie un mot de 5 lettres. Légende : + bonne place, ? mauvaise place, - absente.']);
});
const hang = (g) => [...g.answer].map((l) => (g.found.includes(l) ? l : '_')).join(' ');
cmd('hangman', { usage: 'hangman' }, async (c) => {
  games.set(c.jid, { type: 'hangman', answer: U.pick(WORDS), found: [], bad: [], until: Date.now() + 600000 });
  const g = games.get(c.jid);
  await say(c, 'Pendu', ['Mot : ' + hang(g), 'Erreurs autorisées : 7', 'Envoie une lettre à la fois.']);
});
cmd('guess', { usage: 'guess' }, async (c) => {
  games.set(c.jid, { type: 'guess', answer: U.rand(1, 100), tries: 0, until: Date.now() + 600000 });
  await say(c, 'Nombre mystère', ['J\'ai choisi un nombre entre 1 et 100.', 'Envoie ton estimation dans le chat.']);
});
const LINES = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]];
const board = (b) => [0, 3, 6].map((i) => [0, 1, 2].map((k) => b[i + k] || String(i + k + 1)).join(' | ')).join('\n---------\n');
async function ttt(c) {
  const t = c.target();
  if (!t || t === c.sender) return c.usage(c.prefix + c.cmd + ' @adversaire');
  games.set(c.jid, { type: 'ttt', board: Array(9).fill(null), players: { X: c.sender, O: t }, turn: 'X', until: Date.now() + 900000 });
  await say(c, 'Morpion', [board(Array(9).fill(null)), '@' + U.jidNum(c.sender) + ' joue X, @' + U.jidNum(t) + ' joue O.', 'X commence. Envoie un chiffre de 1 à 9.'], [c.sender, t]);
}
cmd('ttt', { usage: 'ttt @adversaire' }, ttt);
cmd('tictactoe', { usage: 'tictactoe @adversaire' }, ttt);
cmd('wyr', { usage: 'wyr' }, (c) => say(c, 'Tu préfères', [U.pick(WYR)]));
cmd('truth', { usage: 'truth' }, (c) => say(c, 'Vérité', [U.pick(TRUTH)]));
cmd('dare', { usage: 'dare' }, (c) => say(c, 'Action', [U.pick(DARE)]));
cmd('riddle', { usage: 'riddle' }, async (c) => {
  const r = U.pick(RIDDLES);
  games.set(c.jid, { type: 'riddle', answer: strip(r[1]), text: r[1], until: Date.now() + 120000 });
  await say(c, 'Devinette', [r[0], 'Envoie ta réponse dans le chat (2 minutes).']);
});
cmd('8ball', { usage: '8ball <question>' }, async (c) => { if (!c.text) return c.usage(c.prefix + '8ball <question>'); await say(c, 'Boule magique', ['Question : ' + c.text, 'Réponse : ' + U.pick(BALL)]); });
cmd('dice', { usage: 'dice [faces]' }, (c) => { const n = Math.min(Math.max(parseInt(c.args[0], 10) || 6, 2), 1000); return say(c, 'Lancer de dé (' + n + ' faces)', ['Résultat : ' + U.rand(1, n)]); });
cmd('coin', {}, (c) => say(c, 'Pile ou face', ['Résultat : ' + U.pick(['pile', 'face'])]));
cmd('random', { usage: 'random <min> <max>' }, (c) => {
  const a = parseInt(c.args[0], 10), b = parseInt(c.args[1], 10);
  if (isNaN(a) || isNaN(b)) return c.usage(c.prefix + 'random <min> <max>');
  return say(c, 'Nombre aléatoire', [U.rand(Math.min(a, b), Math.max(a, b))]);
});
cmd('pick', { usage: 'pick <choix 1> | <choix 2> | ...' }, (c) => {
  const l = c.text.split('|').map((s) => s.trim()).filter(Boolean);
  if (l.length < 2) return c.usage(c.prefix + 'pick <choix 1> | <choix 2> | ...');
  return say(c, 'Tirage au sort', ['Choix retenu : ' + U.pick(l)]);
});
cmd('rps', { usage: 'rps <pierre|feuille|ciseaux>' }, (c) => {
  const map = { pierre: 0, rock: 0, feuille: 1, papier: 1, paper: 1, ciseaux: 2, scissors: 2 };
  const me = map[(c.args[0] || '').toLowerCase()];
  if (me === undefined) return c.usage(c.prefix + 'rps <pierre|feuille|ciseaux>');
  const bot = U.rand(0, 2), n = ['pierre', 'feuille', 'ciseaux'];
  const res = me === bot ? 'Égalité.' : (me - bot + 3) % 3 === 1 ? 'Tu gagnes.' : 'Je gagne.';
  return say(c, 'Pierre, feuille, ciseaux', ['Toi : ' + n[me], 'Moi : ' + n[bot], res]);
});
cmd('slots', {}, (c) => {
  const S = ['CERISE', 'CITRON', 'CLOCHE', 'ETOILE', 'SEPT'];
  const r = [U.pick(S), U.pick(S), U.pick(S)];
  const win = r[0] === r[1] && r[1] === r[2] ? 'Jackpot, trois symboles identiques.' : r[0] === r[1] || r[1] === r[2] || r[0] === r[2] ? 'Deux symboles identiques, presque.' : 'Perdu, réessaie.';
  return say(c, 'Machine à sous', [r.join(' | '), win]);
});

// Entrees de jeu (messages non commandes)
hooks.text.push(async (c) => {
  const g = games.get(c.jid);
  if (!g) return false;
  if (Date.now() > g.until) { games.delete(c.jid); return false; }
  const t = strip(c.body);
  if (!t) return false;
  if (g.type === 'trivia' && /^[abcd]$/.test(t)) {
    games.delete(c.jid);
    await say(c, t.toUpperCase().charCodeAt(0) - 65 === g.answer ? 'Bonne réponse' : 'Mauvaise réponse', ['La réponse était : ' + g.text]);
    return true;
  }
  if ((g.type === 'scramble' || g.type === 'riddle') && t === strip(g.answer)) {
    games.delete(c.jid);
    await say(c, 'Bravo', ['@' + c.num + ' a trouvé : ' + (g.text || g.answer)], [c.sender]);
    return true;
  }
  if (g.type === 'guess' && /^\d{1,3}$/.test(t)) {
    g.tries++;
    const n = +t;
    if (n === g.answer) { games.delete(c.jid); await say(c, 'Bravo', ['@' + c.num + ' a trouvé ' + n + ' en ' + g.tries + ' essai(s).'], [c.sender]); }
    else await say(c, 'Nombre mystère', [n < g.answer ? 'Plus grand.' : 'Plus petit.', 'Essais : ' + g.tries]);
    return true;
  }
  if (g.type === 'wordle' && /^[a-z]{5}$/.test(t)) {
    const res = [...t].map((l, i) => (l === g.answer[i] ? '+' : g.answer.includes(l) ? '?' : '-')).join('');
    g.tries.push(t.toUpperCase() + '  ' + res);
    if (t === g.answer) { games.delete(c.jid); await say(c, 'Wordle gagné', [...g.tries, 'Mot : ' + g.answer.toUpperCase()]); }
    else if (g.tries.length >= 6) { games.delete(c.jid); await say(c, 'Wordle perdu', [...g.tries, 'Le mot était : ' + g.answer.toUpperCase()]); }
    else await say(c, 'Wordle (' + g.tries.length + '/6)', g.tries);
    return true;
  }
  if (g.type === 'hangman' && /^[a-z]$/.test(t)) {
    if (g.found.includes(t) || g.bad.includes(t)) return true;
    if (g.answer.includes(t)) g.found.push(t); else g.bad.push(t);
    if ([...g.answer].every((l) => g.found.includes(l))) { games.delete(c.jid); await say(c, 'Pendu gagné', ['Mot : ' + g.answer]); }
    else if (g.bad.length >= 7) { games.delete(c.jid); await say(c, 'Pendu perdu', ['Le mot était : ' + g.answer]); }
    else await say(c, 'Pendu', ['Mot : ' + hang(g), 'Erreurs (' + g.bad.length + '/7) : ' + (g.bad.join(', ') || 'aucune')]);
    return true;
  }
  if (g.type === 'ttt' && /^[1-9]$/.test(t)) {
    const who = g.players[g.turn];
    if (U.jidNum(who) !== c.num) return false;
    const i = +t - 1;
    if (g.board[i]) { await say(c, 'Morpion', ['Cette case est déjà prise.']); return true; }
    g.board[i] = g.turn;
    if (LINES.some((l) => l.every((k) => g.board[k] === g.turn))) { games.delete(c.jid); await say(c, 'Morpion : victoire', [board(g.board), '@' + c.num + ' gagne la partie.'], [c.sender]); }
    else if (g.board.every(Boolean)) { games.delete(c.jid); await say(c, 'Morpion : égalité', [board(g.board)]); }
    else { g.turn = g.turn === 'X' ? 'O' : 'X'; await say(c, 'Morpion', [board(g.board), 'Au tour de @' + U.jidNum(g.players[g.turn]) + ' (' + g.turn + ').'], [g.players[g.turn]]); }
    return true;
  }
  return false;
});
