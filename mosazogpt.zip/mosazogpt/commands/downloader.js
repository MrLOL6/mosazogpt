'use strict';
const { cmd } = require('../lib/registry');
const cfg = require('../lib/config');
const U = require('../lib/util');
const Y = require('../lib/ytdlp');
const { upload } = require('../lib/upload');

const VID = ['mp4', 'webm', 'mov', 'mkv'], IMG = ['jpg', 'jpeg', 'png', 'webp', 'gif'], AUD = ['mp3', 'm4a', 'opus', 'ogg', 'wav'];
async function sendFile(c, r, caption) {
  if (VID.includes(r.ext)) return c.sendMedia('video', r.buffer, caption, { mimetype: 'video/mp4' });
  if (IMG.includes(r.ext)) return c.sendMedia('image', r.buffer, caption);
  if (AUD.includes(r.ext)) return c.sendMedia('audio', r.buffer, caption, { mimetype: 'audio/mpeg' });
  return c.sendMedia('document', r.buffer, caption, { mimetype: 'application/octet-stream', fileName: r.title + '.' + r.ext });
}
const needUrl = (c, name) => (U.isUrl(c.args[0]) ? c.args[0] : (c.usage(c.prefix + name + ' <lien>'), null));

// YouTube : recherche ou lien
async function resolveYt(c, name) {
  if (!c.text) { await c.usage(c.prefix + name + ' <titre ou lien YouTube>'); return null; }
  if (U.isUrl(c.args[0])) return { url: c.args[0], title: null };
  const v = (await Y.search(c.text))[0];
  if (!v) { await c.reply('Aucun résultat pour : ' + c.text); return null; }
  return { url: v.url, title: v.title, info: ['Titre : ' + v.title, 'Chaîne : ' + (v.author && v.author.name), 'Durée : ' + v.timestamp, 'Lien : ' + v.url] };
}
function ytAudio(names) {
  cmd(names, { usage: names[0] + ' <titre ou lien YouTube>' }, async (c) => {
    const t = await resolveYt(c, names[0]);
    if (!t) return;
    await c.reply(U.box('Téléchargement audio', t.info || ['Lien : ' + t.url, 'Préparation en cours...']));
    const r = await Y.dl(t.url, { audio: true });
    await c.sendMedia('audio', r.buffer, null, { mimetype: 'audio/mpeg', fileName: r.title + '.mp3' });
  });
}
ytAudio(['play']); ytAudio(['song']); ytAudio(['music']); ytAudio(['ytmp3']); ytAudio(['mp3']);
function ytVideo(names) {
  cmd(names, { usage: names[0] + ' <titre ou lien YouTube>' }, async (c) => {
    const t = await resolveYt(c, names[0]);
    if (!t) return;
    await c.reply(U.box('Téléchargement vidéo', t.info || ['Lien : ' + t.url, 'Préparation en cours...']));
    const r = await Y.dl(t.url);
    await c.sendMedia('video', r.buffer, 'Titre : ' + r.title, { mimetype: 'video/mp4' });
  });
}
ytVideo(['ytmp4']); ytVideo(['video']);
cmd('ytdoc', { usage: 'ytdoc <titre ou lien> [mp3]' }, async (c) => {
  const audio = (c.args[c.args.length - 1] || '').toLowerCase() === 'mp3';
  if (audio) c.args.pop();
  c.text = c.args.join(' ');
  const t = await resolveYt(c, 'ytdoc');
  if (!t) return;
  await c.reply('Préparation du document en cours...');
  const r = await Y.dl(t.url, { audio });
  await c.sendMedia('document', r.buffer, 'Titre : ' + r.title, { mimetype: audio ? 'audio/mpeg' : 'video/mp4', fileName: r.title + (audio ? '.mp3' : '.mp4') });
});
cmd('ytsearch', { usage: 'ytsearch <recherche>' }, async (c) => {
  if (!c.text) return c.usage(c.prefix + 'ytsearch <recherche>');
  const l = (await Y.search(c.text)).slice(0, 6);
  await c.reply(U.box('Résultats YouTube', l.length ? l.map((v, i) => (i + 1) + '. ' + v.title + '\n   ' + v.timestamp + ' - ' + v.url) : ['Aucun résultat.']));
});

// Reseaux sociaux : yt-dlp
function social(names, label) {
  cmd(names, { usage: names[0] + ' <lien ' + label + '>' }, async (c) => {
    const url = needUrl(c, names[0]);
    if (!url) return;
    await c.reply('Téléchargement ' + label + ' en cours...');
    let r;
    if (/tiktok\.com/.test(url)) {
      try {
        const j = await U.getJSON('https://www.tikwm.com/api/?url=' + encodeURIComponent(url));
        if (j.data && j.data.play) r = { buffer: await U.getBuf(j.data.play), ext: 'mp4', title: j.data.title || 'TikTok' };
      } catch (e) { /* yt-dlp en secours */ }
    }
    if (!r) r = await Y.dl(url);
    await sendFile(c, r, 'Source : ' + label + (r.title ? '\n' + r.title.slice(0, 200) : ''));
  });
}
social(['instagram'], 'Instagram'); social(['tiktok', 'tt'], 'TikTok'); social(['facebook', 'fb'], 'Facebook'); social(['pinterest'], 'Pinterest'); social(['xdown'], 'X (Twitter)');

cmd('ringtone', { usage: 'ringtone <nom>' }, async (c) => {
  if (!c.text) return c.usage(c.prefix + 'ringtone <nom>');
  const v = (await Y.search('ringtone ' + c.text))[0];
  if (!v) return c.reply('Aucun résultat.');
  const r = await Y.dl(v.url, { audio: true });
  const cut = await U.ffmpeg(r.buffer, 'mp3', ['-t', '30', '-acodec', 'libmp3lame'], 'mp3');
  await c.sendMedia('audio', cut, 'Sonnerie : ' + v.title + ' (30 secondes)', { mimetype: 'audio/mpeg' });
});

cmd('anime', { usage: 'anime <titre>' }, async (c) => {
  if (!c.text) return c.usage(c.prefix + 'anime <titre>');
  const j = await U.getJSON('https://api.jikan.moe/v4/anime?limit=1&q=' + encodeURIComponent(c.text));
  const a = j.data && j.data[0];
  if (!a) return c.reply('Aucun anime trouvé.');
  const info = ['Titre : ' + a.title, 'Type : ' + a.type + ' - Épisodes : ' + (a.episodes || '?'), 'Statut : ' + a.status, 'Note : ' + (a.score || 'n/a'), 'Année : ' + (a.year || '?'), 'Synopsis : ' + String(a.synopsis || '').slice(0, 500), 'Fiche : ' + a.url, 'Note : le visionnage complet n\'est pas téléchargeable via le bot (droits d\'auteur).'];
  const img = a.images && a.images.jpg && a.images.jpg.large_image_url;
  if (img) await c.sendMedia('image', await U.getBuf(img), U.box('Anime', info));
  else await c.reply(U.box('Anime', info));
});
cmd('gitclone', { usage: 'gitclone <lien GitHub>' }, async (c) => {
  const m = (c.args[0] || '').match(/github\.com\/([^/\s]+)\/([^/\s#?]+)/i);
  if (!m) return c.usage(c.prefix + 'gitclone https://github.com/utilisateur/depot');
  const repo = m[2].replace(/\.git$/, '');
  const buf = await U.getBuf('https://api.github.com/repos/' + m[1] + '/' + repo + '/zipball', { timeout: 120000 });
  if (buf.length > 90 * 1024 * 1024) return c.reply('Dépôt trop volumineux pour WhatsApp.');
  await c.sendMedia('document', buf, 'Dépôt : ' + m[1] + '/' + repo, { mimetype: 'application/zip', fileName: repo + '.zip' });
});
cmd('apk', { usage: 'apk <nom de l\'application>' }, async (c) => {
  if (!c.text) return c.usage(c.prefix + 'apk <nom de l\'application>');
  const j = await U.getJSON('https://ws75.aptoide.com/api/7/apps/search?limit=1&query=' + encodeURIComponent(c.text));
  const a = j.datalist && j.datalist.list && j.datalist.list[0];
  if (!a || !a.file) return c.reply('Application introuvable.');
  const size = a.file.filesize || a.size || 0;
  const info = ['Nom : ' + a.name, 'Paquet : ' + a.package, 'Version : ' + (a.file.vername || '?'), 'Taille : ' + U.fmtBytes(size)];
  if (size > 90 * 1024 * 1024) return c.reply(U.box('Application trouvée', [...info, 'Trop volumineuse pour WhatsApp. Lien : ' + a.file.path]));
  await c.reply(U.box('Téléchargement APK', info));
  await c.sendMedia('document', await U.getBuf(a.file.path, { timeout: 180000 }), 'Application : ' + a.name, { mimetype: 'application/vnd.android.package-archive', fileName: a.name + '.apk' });
});
cmd('mediafire', { usage: 'mediafire <lien>' }, async (c) => {
  const url = needUrl(c, 'mediafire');
  if (!url) return;
  const html = await U.getText(url);
  const m = html.match(/https?:\/\/download[^"'\s]+mediafire\.com[^"'\s]+/i);
  if (!m) return c.reply('Lien de téléchargement introuvable (fichier supprimé ou protégé).');
  const name = decodeURIComponent(m[0].split('/').pop().split('?')[0]) || 'fichier';
  const buf = await U.getBuf(m[0], { timeout: 180000 });
  if (buf.length > 90 * 1024 * 1024) return c.reply('Fichier trop volumineux pour WhatsApp.');
  await c.sendMedia('document', buf, 'Fichier : ' + name, { mimetype: 'application/octet-stream', fileName: name });
});
cmd('pixabay', { usage: 'pixabay <recherche>' }, async (c) => {
  if (!c.text) return c.usage(c.prefix + 'pixabay <recherche>');
  if (!cfg.PIXABAY_KEY) return c.reply('Clé PIXABAY_KEY non configurée (gratuite sur pixabay.com/api/docs).');
  const j = await U.getJSON('https://pixabay.com/api/?key=' + cfg.PIXABAY_KEY + '&per_page=5&q=' + encodeURIComponent(c.text));
  const h = j.hits && j.hits[0];
  if (!h) return c.reply('Aucun résultat.');
  await c.sendMedia('image', await U.getBuf(h.largeImageURL), 'Pixabay : ' + c.text + '\nAuteur : ' + h.user);
});
cmd('gif', { usage: 'gif <recherche>' }, async (c) => {
  if (!c.text) return c.usage(c.prefix + 'gif <recherche>');
  if (!cfg.GIPHY_KEY) return c.reply('Clé GIPHY_KEY non configurée (gratuite sur developers.giphy.com).');
  const j = await U.getJSON('https://api.giphy.com/v1/gifs/search?limit=5&rating=g&api_key=' + cfg.GIPHY_KEY + '&q=' + encodeURIComponent(c.text));
  const g = j.data && U.pick(j.data);
  if (!g) return c.reply('Aucun GIF trouvé.');
  await c.sendMedia('video', await U.getBuf(g.images.original.mp4), 'GIF : ' + c.text, { gifPlayback: true, mimetype: 'video/mp4' });
});
cmd('tourl', { usage: 'tourl (en répondant à un fichier)' }, async (c) => {
  const md = await c.media();
  if (!md) return c.reply('Envoie ou cite un fichier (image, vidéo, audio, document).');
  const link = await upload(md.buffer, 'fichier.' + md.ext, md.mime);
  await c.reply(U.box('Fichier hébergé', ['Lien : ' + link, 'Taille : ' + U.fmtBytes(md.buffer.length)]));
});
cmd('wikimedia', { usage: 'wikimedia <recherche>' }, async (c) => {
  if (!c.text) return c.usage(c.prefix + 'wikimedia <recherche>');
  const j = await U.getJSON('https://commons.wikimedia.org/w/api.php?action=query&format=json&generator=search&gsrnamespace=6&gsrlimit=5&prop=imageinfo&iiprop=url|mime&iiurlwidth=1024&gsrsearch=' + encodeURIComponent(c.text));
  const pages = j.query && Object.values(j.query.pages).filter((p) => p.imageinfo && /^image\/(jpeg|png|webp)/.test(p.imageinfo[0].mime));
  if (!pages || !pages.length) return c.reply('Aucun résultat sur Wikimedia Commons.');
  const p = pages[0];
  await c.sendMedia('image', await U.getBuf(p.imageinfo[0].thumburl || p.imageinfo[0].url), 'Wikimedia : ' + p.title.replace('File:', ''));
});
module.exports = { sendFile };
