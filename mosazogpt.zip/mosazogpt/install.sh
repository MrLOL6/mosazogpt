#!/data/data/com.termux/files/usr/bin/bash
# Installation et lancement de MosazoGPT sur Termux (une seule commande)
# Utilisation : bash install.sh [numero]   (par defaut : 33768841872)
set -e
NUM="${1:-33768841872}"
NUM="${NUM//[^0-9]/}"

echo "[1/5] Mise a jour de Termux..."
pkg update -y && pkg upgrade -y
echo "[2/5] Installation des outils (Node.js, Git, FFmpeg, yt-dlp)..."
pkg install -y nodejs-lts git ffmpeg libwebp || pkg install -y nodejs git ffmpeg
pkg install -y yt-dlp || pip install -U yt-dlp || echo "yt-dlp non installe : les telechargements ne fonctionneront pas."
echo "[3/5] Installation des dependances du bot..."
npm install --omit=dev --no-audit --no-fund
echo "[4/5] Configuration pour +$NUM..."
[ -f .env ] || cp .env.example .env
sed -i "s/^OWNER_NUMBER=.*/OWNER_NUMBER=$NUM/" .env
echo "[5/5] Demarrage... un code d'appairage va s'afficher."
termux-wake-lock 2>/dev/null || true
exec node index.js
