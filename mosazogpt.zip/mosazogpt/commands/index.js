'use strict';
// Chargement de toutes les commandes (ordre sans importance)
for (const f of ['bot', 'owner', 'group', 'ai', 'downloader', 'audio', 'converter', 'logo', 'tools', 'stalk', 'games', 'fun', 'premium']) require('./' + f);
