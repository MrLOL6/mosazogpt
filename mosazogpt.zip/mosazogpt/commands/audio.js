'use strict';
const { cmd } = require('../lib/registry');
const U = require('../lib/util');

const R = 'aresample=44100,';
const FX = {
  bass: 'equalizer=f=54:width_type=o:width=2:g=20',
  deep: R + 'asetrate=44100*0.8,aresample=44100,atempo=1.25',
  blown: 'acrusher=level_in=4:level_out=2:bits=8:mode=log:aa=1',
  earrape: 'volume=25',
  fast: 'atempo=1.5',
  slow: 'atempo=0.7',
  fat: R + 'asetrate=44100*0.85,aresample=44100,atempo=1.15',
  squirrel: R + 'asetrate=44100*1.6,aresample=44100,atempo=0.625',
  nightcore: R + 'asetrate=44100*1.25,aresample=44100',
  robot: "afftfilt=real='hypot(re,im)*sin(0)':imag='hypot(re,im)*cos(0)':win_size=512:overlap=0.75",
  areverse: 'areverse',
};
for (const name of Object.keys(FX)) {
  cmd(name, { usage: name + ' (en répondant à un audio ou une vidéo)' }, async (c) => {
    const md = await c.media(['audio', 'video']);
    if (!md) return c.reply('Réponds à un message audio (ou vidéo) avec ' + c.prefix + name + '.');
    const out = await U.ffmpeg(md.buffer, md.ext, ['-vn', '-af', FX[name], '-acodec', 'libmp3lame', '-b:a', '128k'], 'mp3');
    await c.sendMedia('audio', out, 'Effet appliqué : ' + name, { mimetype: 'audio/mpeg' });
  });
}
cmd('tomp3', { usage: 'tomp3 (en répondant à un audio ou une vidéo)' }, async (c) => {
  const md = await c.media(['audio', 'video', 'document']);
  if (!md) return c.reply('Réponds à un audio ou une vidéo avec ' + c.prefix + 'tomp3.');
  const out = await U.ffmpeg(md.buffer, md.ext, ['-vn', '-acodec', 'libmp3lame', '-b:a', '128k'], 'mp3');
  await c.sendMedia('audio', out, 'Conversion en MP3 terminée.', { mimetype: 'audio/mpeg' });
});
cmd('tts', { usage: 'tts [langue] <texte>' }, async (c) => {
  let lang = 'fr', text = c.text;
  if (/^(fr|en|es|hi|de|it|pt|ar|ja|ko|ru|tr)$/i.test(c.args[0] || '') && c.args.length > 1) { lang = c.args[0].toLowerCase(); text = c.args.slice(1).join(' '); }
  if (!text) return c.usage(c.prefix + 'tts [fr|en|es|hi...] <texte, 200 caractères maximum>');
  if (text.length > 200) return c.reply('Le texte est trop long (200 caractères maximum).');
  const buf = await U.getBuf('https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=' + lang + '&q=' + encodeURIComponent(text));
  await c.sendMedia('audio', buf, 'Synthèse vocale (' + lang + ')', { mimetype: 'audio/mpeg' });
});
