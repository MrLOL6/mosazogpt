'use strict';
const { cmd } = require('../lib/registry');
const cfg = require('../lib/config');
const U = require('../lib/util');
const M = require('../lib/media');
const O = require('./owner');
const { upload } = require('../lib/upload');
const fs = require('fs');

const needImg = async (c) => {
  const md = await c.media(['image']);
  if (!md) await c.reply('Envoie ou cite une image avec ' + c.prefix + c.cmd + '.');
  return md;
};
const sendImg = (c, buf, cap) => c.sendMedia('image', buf, cap);

// ---- Stickers ----
cmd(['sticker', 's'], { usage: 'sticker [pack|auteur] (image ou vidéo)' }, async (c) => {
  const md = await c.media(['image', 'video']);
  if (!md) return c.reply('Envoie ou cite une image / courte vidéo avec ' + c.prefix + c.cmd + '.');
  const [pack, author] = c.text ? c.text.split('|').map((s) => s.trim()) : [];
  const st = await M.toSticker(md.buffer, md.ext, pack || 'MosazoGPT', author || 'Mosa_X', md.type === 'video');
  await c.sendMedia('sticker', st);
});
const toImage = async (c) => {
  const md = await c.media(['sticker']);
  if (!md) return c.reply('Réponds à un sticker avec ' + c.prefix + c.cmd + '.');
  await sendImg(c, await M.webpToPng(md.buffer), 'Sticker converti en image.');
};
cmd('simage', { usage: 'simage (en répondant à un sticker)' }, toImage);
cmd('toimg', { usage: 'toimg (en répondant à un sticker)' }, toImage);
cmd('take', { usage: 'take <pack>|<auteur> (en répondant à un sticker)' }, async (c) => {
  const md = await c.media(['sticker']);
  if (!md) return c.reply('Réponds à un sticker avec ' + c.prefix + 'take <pack>|<auteur>.');
  const [pack, author] = (c.text || 'MosazoGPT|Mosa_X').split('|').map((s) => s.trim());
  await c.sendMedia('sticker', await M.addExif(md.buffer, pack || 'MosazoGPT', author || ''));
});
cmd('tomp4', { usage: 'tomp4 (en répondant à une vidéo, un GIF ou un sticker animé)' }, async (c) => {
  const md = await c.media(['video', 'sticker']);
  if (!md) return c.reply('Réponds à une vidéo, un GIF ou un sticker animé.');
  const out = await U.ffmpeg(md.buffer, md.ext, ['-movflags', 'faststart', '-pix_fmt', 'yuv420p', '-vf', 'scale=trunc(iw/2)*2:trunc(ih/2)*2'], 'mp4');
  await c.sendMedia('video', out, 'Conversion en MP4 terminée.', { mimetype: 'video/mp4' });
});
cmd('voice', { usage: 'voice (en répondant à un audio)' }, async (c) => {
  const md = await c.media(['audio', 'video']);
  if (!md) return c.reply('Réponds à un audio avec ' + c.prefix + 'voice.');
  const out = await U.ffmpeg(md.buffer, md.ext, ['-vn', '-c:a', 'libopus', '-b:a', '48k', '-ar', '48000', '-ac', '1'], 'ogg');
  await c.sendMedia('audio', out, 'Message vocal créé.', { mimetype: 'audio/ogg; codecs=opus', ptt: true });
});

// ---- Filtres d'image (Jimp) ----
function filter(name, fn, cap) {
  cmd(name, { usage: name + ' (en répondant à une image)' }, async (c) => {
    const md = await needImg(c);
    if (!md) return;
    await sendImg(c, await M.jimp(md.buffer, (img, J) => fn(img, J, c)), cap || ('Effet appliqué : ' + name));
  });
}
filter('blur', (i) => i.blur(8));
filter('grayscale', (i) => i.greyscale());
filter('invert', (i) => i.invert());
filter('sepia', (i) => i.sepia());
filter('sharpen', (i) => i.convolute([[0, -1, 0], [-1, 5, -1], [0, -1, 0]]));
filter('character', (i) => i.posterize(5).contrast(0.3), 'Effet dessin appliqué.');
filter('circle', (i) => { const s = Math.min(i.bitmap.width, i.bitmap.height); i.cover(s, s).circle(); }, 'Image arrondie.');
cmd('round', { usage: 'round (en répondant à une image)' }, async (c) => {
  const md = await needImg(c);
  if (!md) return;
  await sendImg(c, await M.jimp(md.buffer, (i) => { const s = Math.min(i.bitmap.width, i.bitmap.height); i.cover(s, s).circle(); }), 'Image arrondie.');
});
cmd('crop', { usage: 'crop [1:1|16:9|4:3] (en répondant à une image)' }, async (c) => {
  const md = await needImg(c);
  if (!md) return;
  const [a, b] = (c.args[0] || '1:1').split(':').map(Number);
  if (!a || !b) return c.usage(c.prefix + 'crop <largeur:hauteur> (exemple 16:9)');
  await sendImg(c, await M.jimp(md.buffer, (i) => { const w = i.bitmap.width, h = i.bitmap.height; let nw = w, nh = Math.round(w * b / a); if (nh > h) { nh = h; nw = Math.round(h * a / b); } i.crop(Math.floor((w - nw) / 2), Math.floor((h - nh) / 2), nw, nh); }), 'Image recadrée en ' + a + ':' + b + '.');
});
cmd('wasted', { usage: 'wasted (en répondant à une image)' }, async (c) => {
  const md = await needImg(c);
  if (!md) return;
  await sendImg(c, await M.jimp(md.buffer, async (i, J) => {
    i.greyscale().brightness(-0.25);
    const font = await J.loadFont(J.FONT_SANS_64_WHITE);
    const bh = Math.max(80, Math.round(i.bitmap.height / 5));
    const band = new J(i.bitmap.width, bh, 0x000000b0);
    band.print(font, 0, 0, { text: 'WASTED', alignmentX: J.HORIZONTAL_ALIGN_CENTER, alignmentY: J.VERTICAL_ALIGN_MIDDLE }, i.bitmap.width, bh);
    i.composite(band, 0, Math.round((i.bitmap.height - bh) / 2));
  }), 'Effet wasted appliqué.');
});
cmd('upscale', { usage: 'upscale (en répondant à une image)' }, async (c) => {
  const md = await needImg(c);
  if (!md) return;
  const out = await U.ffmpeg(md.buffer, md.ext, ['-vf', 'scale=iw*2:ih*2:flags=lanczos,unsharp=5:5:0.8', '-frames:v', '1'], 'png');
  await sendImg(c, out, 'Image agrandie x2 et affinée.');
});
cmd('removebg', { usage: 'removebg (en répondant à une image)' }, async (c) => {
  if (!cfg.REMOVEBG_KEY) return c.reply('Clé REMOVEBG_KEY non configurée (50 images gratuites par mois sur remove.bg/api).');
  const md = await needImg(c);
  if (!md) return;
  const fd = new FormData();
  fd.append('image_file', new Blob([md.buffer], { type: md.mime || 'image/png' }), 'image.' + md.ext);
  fd.append('size', 'auto');
  const res = await U.http('https://api.remove.bg/v1.0/removebg', { method: 'POST', body: fd, headers: { 'X-Api-Key': cfg.REMOVEBG_KEY }, timeout: 90000 });
  await c.sendMedia('document', Buffer.from(await res.arrayBuffer()), 'Fond supprimé.', { mimetype: 'image/png', fileName: 'sans-fond.png' });
});

// ---- Texte en image / sticker ----
async function textImage(text, { bg, w = 512, h = 512 }) {
  return M.jimp(Buffer.from(require('fs').readFileSync(require('path').join(cfg.ROOT, 'data', 'blank.png'))), async (img, J) => {
    const font = await J.loadFont(J.FONT_SANS_64_BLACK);
    const base = new J(w, h, bg);
    base.print(font, 20, 20, { text, alignmentX: J.HORIZONTAL_ALIGN_CENTER, alignmentY: J.VERTICAL_ALIGN_MIDDLE }, w - 40, h - 40);
    return base;
  });
}
cmd('ttp', { usage: 'ttp <texte>' }, async (c) => {
  if (!c.text) return c.usage(c.prefix + 'ttp <texte>');
  await sendImg(c, await textImage(c.text.slice(0, 80), { bg: 0xffffffff }), 'Texte : ' + c.text.slice(0, 80));
});
cmd('attp', { usage: 'attp <texte>' }, async (c) => {
  if (!c.text) return c.usage(c.prefix + 'attp <texte>');
  const colors = [0xff595eff, 0xffca3aff, 0x8ac926ff, 0x1982c4ff, 0x6a4c93ff];
  const dir = U.tmpFile('');
  fs.mkdirSync(dir);
  try {
    for (let i = 0; i < colors.length; i++) fs.writeFileSync(dir + '/f' + i + '.png', await textImage(c.text.slice(0, 60), { bg: colors[i] }));
    const out = U.tmpFile('webp');
    const r = await U.run('ffmpeg', ['-y', '-framerate', '3', '-i', dir + '/f%d.png', '-vcodec', 'libwebp', '-lossless', '0', '-q:v', '50', '-loop', '0', out]);
    if (!fs.existsSync(out)) throw new Error('Création du sticker animé impossible : ' + r.stderr.split('\n').slice(-2).join(' '));
    const st = await M.addExif(fs.readFileSync(out), 'MosazoGPT', 'Mosa_X');
    U.rm(out);
    await c.sendMedia('sticker', st);
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
});
cmd('qc', { usage: 'qc <texte> (ou en répondant à un message)' }, async (c) => {
  const q = c.quoted && (c.quoted.message.conversation || (c.quoted.message.extendedTextMessage && c.quoted.message.extendedTextMessage.text));
  const text = (c.text || q || '').slice(0, 200);
  if (!text) return c.usage(c.prefix + 'qc <texte> (ou en répondant à un message)');
  const who = c.quoted ? c.quoted.participant : c.sender;
  const name = c.name(who);
  const buf = await M.jimp(fs.readFileSync(cfg.ROOT + '/data/blank.png'), async (img, J) => {
    const f1 = await J.loadFont(J.FONT_SANS_32_WHITE), f2 = await J.loadFont(J.FONT_SANS_32_WHITE);
    const base = new J(512, 512, 0x1f2c34ff);
    base.print(f1, 24, 24, name.slice(0, 24), 464);
    base.print(f2, 24, 80, { text, alignmentX: J.HORIZONTAL_ALIGN_LEFT }, 464, 400);
    return base;
  });
  await c.sendMedia('sticker', await M.toSticker(buf, 'png'));
});
cmd('emojimix', { usage: 'emojimix <emoji1>+<emoji2>' }, async (c) => {
  const e = [...c.text.replace(/\s|\+/g, '')].filter((x) => /\p{Extended_Pictographic}/u.test(x));
  if (e.length < 2) return c.usage(c.prefix + 'emojimix <emoji1>+<emoji2>');
  const j = await U.getJSON('https://tenor.googleapis.com/v2/featured?key=AIzaSyACvEq5cnT7AcHpDbtmQcCD70I5ZvB5V7Y&contentfilter=high&media_filter=png_transparent&component=proactive&collection=emoji_kitchen_v5&q=' + encodeURIComponent(e[0] + '_' + e[1]));
  const url = j.results && j.results[0] && j.results[0].media_formats.png_transparent.url;
  if (!url) return c.reply('Ce mélange d\'emojis n\'existe pas.');
  await c.sendMedia('sticker', await M.toSticker(await U.getBuf(url), 'png'));
});
cmd('tgsticker', { usage: 'tgsticker <lien t.me/addstickers/NOM>' }, async (c) => {
  const m = c.text.match(/addstickers\/([\w]+)/);
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!m) return c.usage(c.prefix + 'tgsticker https://t.me/addstickers/NOM');
  if (!token) return c.reply('Cette commande nécessite un jeton de bot Telegram gratuit (variable TELEGRAM_BOT_TOKEN, à créer avec @BotFather).');
  const set = await U.getJSON('https://api.telegram.org/bot' + token + '/getStickerSet?name=' + m[1]);
  const list = set.result.stickers.filter((s) => !s.is_animated && !s.is_video).slice(0, 10);
  await c.reply('Envoi de ' + list.length + ' sticker(s) du pack : ' + set.result.title);
  for (const s of list) {
    const f = await U.getJSON('https://api.telegram.org/bot' + token + '/getFile?file_id=' + s.file_id);
    const buf = await U.getBuf('https://api.telegram.org/file/bot' + token + '/' + f.result.file_path);
    await c.sendMedia('sticker', await M.addExif(buf, set.result.title, 'Mosa_X'));
    await U.sleep(800);
  }
});

// ---- Memes ----
cmd('meme', { usage: 'meme <texte haut> | <texte bas> (en répondant à une image)' }, async (c) => {
  const md = await needImg(c);
  if (!md) return;
  const [top, bottom] = c.text.split('|').map((s) => s.trim());
  if (!top && !bottom) return c.usage(c.prefix + 'meme <texte haut> | <texte bas>');
  await sendImg(c, await M.jimp(md.buffer, async (i, J) => {
    i.resize(Math.min(i.bitmap.width, 800), J.AUTO);
    const w = i.bitmap.width, h = i.bitmap.height;
    const fw = await J.loadFont(J.FONT_SANS_32_WHITE), fb = await J.loadFont(J.FONT_SANS_32_BLACK);
    const put = (t, y) => { if (!t) return; for (const [dx, dy] of [[-2, 0], [2, 0], [0, -2], [0, 2]]) i.print(fb, dx, y + dy, { text: t.toUpperCase(), alignmentX: J.HORIZONTAL_ALIGN_CENTER }, w); i.print(fw, 0, y, { text: t.toUpperCase(), alignmentX: J.HORIZONTAL_ALIGN_CENTER }, w); };
    put(top, 10); put(bottom, h - 60);
  }), 'Mème créé.');
});
cmd('memegen', { usage: 'memegen <modèle> | <texte haut> | <texte bas>' }, async (c) => {
  const p = c.text.split('|').map((s) => s.trim());
  if (p.length < 2) return c.usage(c.prefix + 'memegen <modèle> | <texte haut> | <texte bas>   (modèles : buzz, doge, drake, fine, rollsafe, success...)');
  const enc = (s) => encodeURIComponent((s || '_').replace(/ /g, '_').replace(/\?/g, '~q').replace(/\//g, '~s'));
  await sendImg(c, await U.getBuf('https://api.memegen.link/images/' + encodeURIComponent(p[0]) + '/' + enc(p[1]) + '/' + enc(p[2]) + '.png'), 'Modèle : ' + p[0]);
});
cmd('getpp', { usage: 'getpp @membre' }, async (c) => {
  const t = c.target() || c.sender;
  await O.ppSend(c, t, '+' + U.jidNum(t));
});
