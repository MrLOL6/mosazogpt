'use strict';
const { cmd } = require('../lib/registry');
const U = require('../lib/util');

const og = async (url) => {
  const h = await U.getText(url, { headers: { 'Accept-Language': 'fr,en;q=0.8' } });
  const get = (p) => { const m = h.match(new RegExp('<meta[^>]+(?:property|name)="' + p + '"[^>]+content="([^"]*)"', 'i')) || h.match(new RegExp('<meta[^>]+content="([^"]*)"[^>]+(?:property|name)="' + p + '"', 'i')); return m ? m[1].replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#39;/g, '\'') : ''; };
  return { title: get('og:title'), desc: get('og:description'), image: get('og:image') };
};
const user = (c, name, ex) => { const u = (c.args[0] || '').replace(/^@/, ''); if (!u) { c.usage(c.prefix + name + ' ' + ex); return null; } return u; };
const send = async (c, title, lines, img) => {
  if (img) { try { return await c.sendMedia('image', await U.getBuf(img), U.box(title, lines)); } catch (e) { /* texte seul */ } }
  return c.reply(U.box(title, lines));
};

cmd('gitstalk', { usage: 'gitstalk <utilisateur>' }, async (c) => {
  const u = user(c, 'gitstalk', '<utilisateur GitHub>'); if (!u) return;
  const j = await U.getJSON('https://api.github.com/users/' + encodeURIComponent(u), { allowError: true });
  if (!j.login) return c.reply('Utilisateur GitHub introuvable.');
  await send(c, 'Profil GitHub', ['Pseudo : ' + j.login, 'Nom : ' + (j.name || '-'), 'Bio : ' + (j.bio || '-'), 'Dépôts publics : ' + j.public_repos, 'Abonnés : ' + j.followers + ' - Abonnements : ' + j.following, 'Localisation : ' + (j.location || '-'), 'Créé le : ' + String(j.created_at).slice(0, 10), 'Lien : ' + j.html_url], j.avatar_url);
});
cmd('npmstalk', { usage: 'npmstalk <paquet>' }, async (c) => {
  const u = user(c, 'npmstalk', '<paquet>'); if (!u) return;
  const j = await U.getJSON('https://registry.npmjs.org/' + encodeURIComponent(u), { allowError: true });
  if (!j.name) return c.reply('Paquet introuvable.');
  const v = j['dist-tags'] && j['dist-tags'].latest;
  await c.reply(U.box('Paquet NPM', ['Nom : ' + j.name, 'Dernière version : ' + v, 'Description : ' + (j.description || '-'), 'Licence : ' + (j.license || '-'), 'Versions publiées : ' + Object.keys(j.versions || {}).length, 'Lien : https://www.npmjs.com/package/' + j.name]));
});
cmd('tgstalk', { usage: 'tgstalk <utilisateur>' }, async (c) => {
  const u = user(c, 'tgstalk', '<nom d\'utilisateur Telegram>'); if (!u) return;
  const o = await og('https://t.me/' + encodeURIComponent(u));
  if (!o.title) return c.reply('Profil Telegram introuvable.');
  await send(c, 'Profil Telegram', ['Nom : ' + o.title.replace(/^Telegram: Contact /, ''), 'Description : ' + (o.desc || '-'), 'Lien : https://t.me/' + u], o.image);
});
cmd('ttstalk', { usage: 'ttstalk <utilisateur>' }, async (c) => {
  const u = user(c, 'ttstalk', '<utilisateur TikTok>'); if (!u) return;
  const j = await U.getJSON('https://www.tikwm.com/api/user/info?unique_id=' + encodeURIComponent(u), { allowError: true });
  if (!j.data || !j.data.user) return c.reply('Profil TikTok introuvable.');
  const d = j.data.user, s = j.data.stats;
  await send(c, 'Profil TikTok', ['Pseudo : @' + d.uniqueId, 'Nom : ' + d.nickname, 'Bio : ' + (d.signature || '-'), 'Abonnés : ' + s.followerCount, 'Abonnements : ' + s.followingCount, 'J\'aime : ' + s.heartCount, 'Vidéos : ' + s.videoCount, 'Lien : https://www.tiktok.com/@' + d.uniqueId], d.avatarLarger);
});
cmd('xstalk', { usage: 'xstalk <utilisateur>' }, async (c) => {
  const u = user(c, 'xstalk', '<utilisateur X>'); if (!u) return;
  const j = await U.getJSON('https://api.fxtwitter.com/' + encodeURIComponent(u), { allowError: true });
  const d = j.user;
  if (!d) return c.reply('Profil X introuvable.');
  await send(c, 'Profil X (Twitter)', ['Pseudo : @' + d.screen_name, 'Nom : ' + d.name, 'Bio : ' + (d.description || '-'), 'Abonnés : ' + d.followers, 'Abonnements : ' + d.following, 'Publications : ' + d.tweets, 'Lien : ' + d.url], d.avatar_url && d.avatar_url.replace('_normal', '_400x400'));
});
cmd('thrstalk', { usage: 'thrstalk <utilisateur>' }, async (c) => {
  const u = user(c, 'thrstalk', '<utilisateur Threads>'); if (!u) return;
  const o = await og('https://www.threads.net/@' + encodeURIComponent(u));
  if (!o.title) return c.reply('Profil Threads introuvable ou inaccessible.');
  await send(c, 'Profil Threads', ['Nom : ' + o.title, 'Description : ' + (o.desc || '-'), 'Lien : https://www.threads.net/@' + u], o.image);
});
cmd('pinstalk', { usage: 'pinstalk <utilisateur>' }, async (c) => {
  const u = user(c, 'pinstalk', '<utilisateur Pinterest>'); if (!u) return;
  const o = await og('https://www.pinterest.com/' + encodeURIComponent(u) + '/');
  if (!o.title) return c.reply('Profil Pinterest introuvable.');
  await send(c, 'Profil Pinterest', ['Nom : ' + o.title, 'Description : ' + (o.desc || '-'), 'Lien : https://www.pinterest.com/' + u + '/'], o.image);
});
cmd('genshin', { usage: 'genshin <UID>' }, async (c) => {
  const uid = (c.args[0] || '').replace(/\D/g, '');
  if (!uid) return c.usage(c.prefix + 'genshin <UID à 9 chiffres>');
  const j = await U.getJSON('https://enka.network/api/uid/' + uid + '?info', { allowError: true });
  const p = j.playerInfo;
  if (!p) return c.reply('Joueur introuvable (UID invalide ou profil privé).');
  await c.reply(U.box('Joueur Genshin Impact', ['Pseudo : ' + p.nickname, 'UID : ' + uid, 'Niveau d\'aventure : ' + p.level, 'Niveau du monde : ' + p.worldLevel, 'Succès : ' + p.finishAchievementNum, 'Abysse : étage ' + (p.towerFloorIndex || 0) + ', salle ' + (p.towerLevelIndex || 0), 'Signature : ' + (p.signature || '-')]));
});
