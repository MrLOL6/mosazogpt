# MosazoGPT 1.2.0
Bot WhatsApp multi-sessions (Baileys) avec site d'appairage.
- Termux : `bash install.sh 33768841872`
- Render : voir Dockerfile, variables dans .env.example
Commandes : `.menu` ; aide : `.help <commande>` ; langue : `.lang fr|en|hi|es`
