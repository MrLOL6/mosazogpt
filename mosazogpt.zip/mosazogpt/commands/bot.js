'use strict';
const os = require('os');
const { cmd } = require('../lib/registry');
const cfg = require('../lib/config');
const I = require('../lib/i18n');
const U = require('../lib/util');

cmd('menu', { usage: 'menu' }, async (c) => {
  await c.reply(await I.renderMenu(c.lang, c.prefix));
});

cmd('owner', {}, async (c) => {
  const num = cfg.OWNER_NUMBER || c.entry.id;
  const vcard = 'BEGIN:VCARD\nVERSION:3.0\nFN:' + cfg.AUTHOR + '\nORG:MosazoGPT;\nTEL;type=CELL;type=VOICE;waid=' + num + ':+' + num + '\nEND:VCARD';
  await c.send({ contacts: { displayName: cfg.AUTHOR, contacts: [{ vcard }] } });
  await c.reply(U.box('Créateur', ['Nom : ' + cfg.AUTHOR, 'Numéro : +' + num]));
});

cmd('ping', {}, async (c) => {
  const t = Date.now();
  const r = await c.reply('Mesure de la latence en cours...');
  const ms = Date.now() - t;
  try { await c.sock.sendMessage(c.jid, { text: U.box('Latence', ['Réponse du bot : ' + ms + ' ms']) + '\n\n' + cfg.SIGNATURE, edit: r.key }); }
  catch (e) { await c.reply('Latence : ' + ms + ' ms'); }
});

cmd('alive', {}, async (c) => {
  const st = c.entry.manager.stats();
  await c.reply(U.box('MosazoGPT est en ligne', [
    'Version : ' + cfg.VERSION,
    'Connecté depuis : ' + U.fmtDur((Date.now() - c.entry.since) / 1000),
    'Mode : ' + c.S.mode,
    'Langue : ' + I.LANGS[c.S.lang],
    'Préfixe : ' + c.S.prefix,
    'Sessions actives : ' + st.open + '/' + st.total,
  ]));
});

cmd('runtime', {}, async (c) => {
  await c.reply(U.box('Temps de fonctionnement', [
    'Serveur : ' + U.fmtDur(process.uptime()),
    'Session : ' + U.fmtDur((Date.now() - c.entry.since) / 1000),
    'Système : ' + U.fmtDur(os.uptime()),
  ]));
});

cmd('repo', {}, async (c) => {
  await c.reply(U.box('Dépôt du projet', [
    cfg.REPO_URL ? 'Code source : ' + cfg.REPO_URL : 'Le dépôt n\'est pas configuré (variable REPO_URL).',
    cfg.PUBLIC_URL ? 'Ajouter le bot à son numéro : ' + cfg.PUBLIC_URL : null,
  ]));
});
