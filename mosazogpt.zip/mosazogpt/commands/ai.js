'use strict';
const { cmd } = require('../lib/registry');
const ai = require('../lib/ai');
const U = require('../lib/util');
const { upload } = require('../lib/upload');

const LABEL = { gemini: 'Gemini (Google)', groq: 'Llama (via Groq)', poll: 'Modèle libre (Pollinations)' };
function askCmd(name, provider) {
  cmd(name, { usage: name + ' <question>' }, async (c) => {
    const q = c.text || (c.quoted && (c.quoted.message.conversation || (c.quoted.message.extendedTextMessage && c.quoted.message.extendedTextMessage.text))) || '';
    if (!q) return c.usage(c.prefix + name + ' <ta question>');
    const r = await ai.ask(q, { provider, system: c.S.persona || ai.DEFAULT_SYSTEM });
    await c.reply(U.box('Réponse IA', [r.text, '', 'Modèle : ' + LABEL[r.provider]]));
  });
}
askCmd('ai'); askCmd('gpt', 'groq'); askCmd('gemini', 'gemini');

// Generation d'images (Pollinations, gratuit). dalle et diffusion utilisent des modeles libres equivalents.
function imgCmd(name, model, label) {
  cmd(name, { usage: name + ' <description>' }, async (c) => {
    if (!c.text) return c.usage(c.prefix + name + ' <description de l\'image>');
    await c.reply('Génération de l\'image en cours (' + label + ')...');
    const buf = await U.getBuf(ai.imageUrl(c.text, model), { timeout: 120000 });
    await c.sendMedia('image', buf, 'Prompt : ' + c.text + '\nModèle : ' + label);
  });
}
imgCmd('imagine', 'flux', 'Flux'); imgCmd('flux', 'flux', 'Flux'); imgCmd('dalle', 'flux', 'Flux (alternative libre à DALL-E)'); imgCmd('diffusion', 'turbo', 'Diffusion rapide (SDXL Turbo)');

const noVideo = (name) => cmd(name, { usage: name + ' <description>' }, async (c) => {
  await c.reply('La génération de vidéo par IA n\'est pas disponible gratuitement de façon fiable, la commande est donc désactivée.\nAlternative : ' + c.prefix + 'imagine <description> pour générer une image.');
});
noVideo('txt2video'); noVideo('sora');

cmd('imageedit', { usage: 'imageedit <instruction> (en répondant à une image)' }, async (c) => {
  if (!c.text) return c.usage(c.prefix + 'imageedit <instruction> (en répondant à une image)');
  const md = await c.media(['image']);
  if (!md) return c.reply('Envoie ou cite une image avec la commande.');
  const link = await upload(md.buffer, 'image.' + md.ext, md.mime);
  const buf = await U.getBuf(ai.imageUrl(c.text, 'kontext', '&image=' + encodeURIComponent(link)), { timeout: 150000 });
  await c.sendMedia('image', buf, 'Instruction : ' + c.text);
});
