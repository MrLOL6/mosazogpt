'use strict';
const { cmd } = require('../lib/registry');
const U = require('../lib/util');
const O = require('./owner');
const stateTxt = (v) => (v ? 'activé' : 'désactivé');
const PR = { level: 'premium' };

cmd('premium', { usage: 'premium [add|del|list] [@membre]' }, async (c) => {
  const sub = (c.args[0] || '').toLowerCase();
  if (['add', 'del', 'list'].includes(sub)) {
    if (!c.isOwner) return c.reply(c.t('err_owner'));
    if (sub === 'list') return c.reply(U.box('Utilisateurs premium', c.S.premium.length ? c.S.premium.map((n, i) => (i + 1) + '. @' + n) : ['Aucun utilisateur premium.']), c.S.premium.map(U.toJid));
    const t = c.target();
    if (!t) return c.usage(c.prefix + 'premium ' + sub + ' @membre');
    const n = U.jidNum(t);
    c.S.premium = sub === 'add' ? [...new Set([...c.S.premium, n])] : c.S.premium.filter((x) => x !== n);
    c.S.save();
    return c.reply('@' + n + (sub === 'add' ? ' est maintenant premium.' : ' n\'est plus premium.'), [t]);
  }
  const mine = c.isOwner || c.S.premium.includes(c.num);
  await c.reply(U.box('Fonctions premium', [
    'Ton statut : ' + (mine ? 'accès premium' : 'accès standard'),
    'Gratuit : le statut premium est attribué par le propriétaire du bot.',
    'Fonctions : ' + ['setbotpp', 'autoreply', 'away', 'schedule', 'filter', 'persona', 'ghost'].map((x) => c.prefix + x).join(', '),
    c.isOwner ? 'Gestion : ' + c.prefix + 'premium add|del|list @membre' : null,
  ]));
});
cmd('setbotpp', { ...PR, usage: 'setbotpp (en répondant à une image)' }, O.setBotPhoto);

cmd('autoreply', { ...PR, usage: 'autoreply add <mot> | <réponse> | del <mot> | list' }, async (c) => {
  const sub = (c.args[0] || '').toLowerCase();
  const rest = c.args.slice(1).join(' ');
  if (sub === 'add') {
    const [k, r] = rest.split('|').map((s) => s.trim());
    if (!k || !r) return c.usage(c.prefix + 'autoreply add <mot déclencheur> | <réponse>');
    c.S.autoreply = c.S.autoreply.filter((x) => x.k !== k.toLowerCase());
    c.S.autoreply.push({ k: k.toLowerCase(), r }); c.S.save();
    return c.reply('Réponse automatique ajoutée pour : ' + k);
  }
  if (sub === 'del') { c.S.autoreply = c.S.autoreply.filter((x) => x.k !== rest.toLowerCase()); c.S.save(); return c.reply('Réponse automatique supprimée : ' + rest); }
  if (sub === 'list') return c.reply(U.box('Réponses automatiques', c.S.autoreply.length ? c.S.autoreply.map((x, i) => (i + 1) + '. ' + x.k + ' -> ' + x.r) : ['Aucune règle.']));
  await c.reply(U.box('Réponses automatiques', ['Utilisation : ' + c.prefix + 'autoreply add <mot> | <réponse>', c.prefix + 'autoreply del <mot>', c.prefix + 'autoreply list']));
});
cmd('away', { ...PR, usage: 'away <on|off|set <message>>' }, async (c) => {
  const sub = (c.args[0] || '').toLowerCase();
  if (sub === 'set') { const t = c.args.slice(1).join(' '); if (!t) return c.usage(c.prefix + 'away set <message>'); c.S.away.text = t; c.S.away.on = true; c.S.save(); return c.reply('Message d\'absence enregistré et activé.'); }
  const v = U.onoff(sub);
  if (v === null) return c.reply(U.box('Message d\'absence', ['État : ' + stateTxt(c.S.away.on), 'Texte : ' + c.S.away.text, 'Utilisation : ' + c.prefix + 'away <on|off|set <message>>']));
  c.S.away.on = v; c.S.save();
  await c.reply('Message d\'absence : ' + stateTxt(v));
});
cmd('schedule', { ...PR, usage: 'schedule <+10m|HH:MM> <numéro|ici> <message>' }, async (c) => {
  const at = U.parseWhen(c.args[0]);
  const dest = (c.args[1] || '').toLowerCase();
  const text = c.args.slice(2).join(' ');
  if (!at || !dest || !text) return c.usage(c.prefix + 'schedule <+10m ou HH:MM> <numéro ou "ici"> <message>');
  const jid = dest === 'ici' ? c.jid : dest.includes('@') ? dest : U.toJid(dest);
  c.S.jobs.push({ id: Date.now().toString(36), type: 'msg', at, jid, text }); c.S.save();
  await c.reply('Message programmé pour le ' + new Date(at).toLocaleString('fr-FR', { timeZone: require('../lib/config').TZ }) + '.');
});
cmd('filter', { ...PR, usage: 'filter add <mot> | del <mot> | list' }, async (c) => {
  const sub = (c.args[0] || '').toLowerCase(), w = c.args.slice(1).join(' ').toLowerCase();
  if (sub === 'add' && w) { if (!c.S.filters.includes(w)) c.S.filters.push(w); c.S.save(); return c.reply('Mot filtré dans tous les groupes : ' + w); }
  if (sub === 'del' && w) { c.S.filters = c.S.filters.filter((x) => x !== w); c.S.save(); return c.reply('Mot retiré du filtre : ' + w); }
  await c.reply(U.box('Filtre global', [c.S.filters.length ? c.S.filters.map((x, i) => (i + 1) + '. ' + x).join('\n') : 'Aucun mot filtré.', 'Utilisation : ' + c.prefix + 'filter add <mot> | del <mot>', 'Les messages contenant ces mots sont supprimés dans les groupes où le bot est administrateur.']));
});
cmd('persona', { ...PR, usage: 'persona <description> | reset' }, async (c) => {
  if ((c.args[0] || '').toLowerCase() === 'reset') { c.S.persona = ''; c.S.save(); return c.reply('Personnalité par défaut rétablie.'); }
  if (!c.text) return c.reply(U.box('Personnalité de l\'IA', [c.S.persona || 'Personnalité par défaut.', 'Utilisation : ' + c.prefix + 'persona <description du caractère de l\'IA> | reset']));
  c.S.persona = 'Tu es un assistant WhatsApp. ' + c.text + ' Réponds sans emoji et de façon structurée.'; c.S.save();
  await c.reply('Personnalité de l\'IA enregistrée. Elle s\'applique aux commandes IA et au chatbot.');
});
cmd('ghost', { ...PR, usage: 'ghost <on|off>' }, async (c) => {
  const v = U.onoff(c.args[0]);
  if (v === null) return c.reply(U.box('Mode fantôme', ['État : ' + stateTxt(c.S.ghost), 'Utilisation : ' + c.prefix + 'ghost <on|off>', 'Masque la présence en ligne et les confirmations de lecture.']));
  c.S.ghost = v; c.S.save();
  try {
    await c.sock.updateReadReceiptsPrivacy(v ? 'none' : 'all');
    await c.sock.sendPresenceUpdate(v ? 'unavailable' : 'available');
  } catch (e) { /* ignore */ }
  await c.reply('Mode fantôme : ' + stateTxt(v));
});
