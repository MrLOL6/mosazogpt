'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const B = require('@whiskeysockets/baileys');
const { cmd, cmds } = require('../lib/registry');
const cfg = require('../lib/config');
const store = require('../lib/store');
const I = require('../lib/i18n');
const U = require('../lib/util');
const H = require('../lib/handler');

const getQuoted = (c) => (c.quoted ? (c.entry.msgs.get(c.quoted.id) || { key: c.quoted.key, message: c.quoted.message }) : null);
const stateTxt = (v) => (v ? 'activé' : 'désactivé');
const nowSec = () => Math.floor(Date.now() / 1000);
const hash = (s) => crypto.createHash('sha256').update(String(s)).digest('hex');

async function ppSend(c, jid, label) {
  let url;
  try { url = await c.sock.profilePictureUrl(jid, 'image'); } catch (e) { return c.reply('Aucune photo de profil accessible pour ' + label + '.'); }
  await c.sendMedia('image', await U.getBuf(url), 'Photo de profil : ' + label);
}

// ---- Aide et langue ----
cmd('help', { usage: 'help <commande>' }, async (c) => {
  let q = (c.args[0] || '').toLowerCase();
  if (q.startsWith(c.prefix)) q = q.slice(c.prefix.length);
  if (!q) return c.reply(c.t('help_usage', { p: c.prefix }));
  const found = I.findItem(q);
  const def = cmds.get(q);
  if (!found || !def) return c.reply(c.t('help_nf', { x: q, p: c.prefix }));
  const d = (await I.descs(c.lang))[found.idx];
  const lvl = { all: 'lvl_all', owner: 'lvl_owner', admin: 'lvl_admin', premium: 'lvl_premium' }[def.level];
  const access = c.t(lvl) + (def.group ? c.t('grp_only') : '');
  const others = found.item.names.filter((n) => n !== q && cmds.get(n) === def);
  await c.reply(U.box(c.prefix + q, [
    c.t('help_cat') + ' : ' + found.item.cat,
    c.t('help_desc') + ' : ' + d,
    c.t('help_use') + ' : ' + c.prefix + (def.usage || q),
    others.length ? c.t('help_alias') + ' : ' + others.map((n) => c.prefix + n).join(', ') : null,
    c.t('help_acc') + ' : ' + access,
  ]));
});

cmd('lang', { level: 'owner', usage: 'lang <fr|en|hi|es>' }, async (c) => {
  const l = I.parseLang(c.args[0]);
  if (!l) return c.reply(c.t('lang_usage', { p: c.prefix, lang: I.LANGS[c.S.lang] }));
  c.S.lang = l; c.S.save();
  I.descs(l).catch(() => {});
  await c.reply(I.tx(l, 'lang_set', { lang: I.LANGS[l], p: c.prefix }));
});

// ---- Configuration ----
cmd('mode', { level: 'owner', usage: 'mode <public|prive|groupes>' }, async (c) => {
  const map = { public: 'public', publique: 'public', private: 'private', prive: 'private', 'privé': 'private', groups: 'groups', group: 'groups', groupe: 'groups', groupes: 'groups' };
  const m = map[(c.args[0] || '').toLowerCase()];
  const names = { public: 'public (tout le monde)', private: 'privé (propriétaire et sudo uniquement)', groups: 'groupes (utilisable uniquement dans les groupes, sauf propriétaire)' };
  if (!m) return c.reply(U.box('Mode actuel', [names[c.S.mode], 'Utilisation : ' + c.prefix + 'mode <public|prive|groupes>']));
  c.S.mode = m; c.S.save();
  await c.reply('Mode défini : ' + names[m]);
});

cmd('settings', { level: 'owner' }, async (c) => {
  const S = c.S;
  await c.reply(U.box('Configuration du bot', [
    'Numéro : +' + c.entry.id, 'Préfixe : ' + S.prefix, 'Mode : ' + S.mode, 'Langue : ' + I.LANGS[S.lang],
    'Mot de passe owner : ' + (S.password ? 'défini' : 'non défini'),
    'Sudo : ' + S.sudo.length, 'Bannis : ' + S.banned.length, 'Premium : ' + S.premium.length,
    'Autobio : ' + stateTxt(S.autobio.on), 'Autostatus : ' + stateTxt(S.autostatus),
    'Autotyping : ' + stateTxt(S.autotyping), 'Autorecording : ' + stateTxt(S.autorecording), 'Autoreact : ' + stateTxt(S.autoreact),
    'Anticall : ' + stateTxt(S.anticall), 'Antidelete : ' + (S.antidelete === 'off' ? 'désactivé' : S.antidelete === 'owner' ? 'envoi au propriétaire' : 'dans la discussion'),
    'Antideletestatus : ' + stateTxt(S.antideletestatus), 'Chatbot IA : ' + stateTxt(S.chatbot),
    'Message d\'absence : ' + stateTxt(S.away.on), 'Mode fantôme : ' + stateTxt(S.ghost),
    'Tâches programmées : ' + S.jobs.length,
  ]));
});

cmd('password', { usage: 'password set <mdp> | del | status | <mdp>' }, async (c) => {
  const sub = (c.args[0] || '').toLowerCase();
  if (c.isOwner && sub === 'set') {
    const pw = c.args.slice(1).join(' ');
    if (pw.length < 4) return c.reply('Le mot de passe doit contenir au moins 4 caractères.\nUtilisation : ' + c.prefix + 'password set <mot de passe>');
    c.S.password = hash(pw); c.S.save();
    try { await c.sock.sendMessage(c.jid, { delete: c.m.key }); } catch (e) { /* ignore */ }
    return c.reply('Mot de passe owner défini. Les utilisateurs qui connaissent ce mot de passe peuvent devenir sudo avec ' + c.prefix + 'password <mot de passe>.');
  }
  if (c.isOwner && sub === 'del') { c.S.password = null; c.S.save(); return c.reply('Mot de passe owner supprimé.'); }
  if (c.isOwner && sub === 'status') return c.reply('Mot de passe owner : ' + (c.S.password ? 'défini' : 'non défini'));
  if (!c.text) return c.usage(c.prefix + 'password <mot de passe>' + (c.isOwner ? '\n' + c.prefix + 'password set <mdp> | del | status' : ''));
  if (c.isGroup) return c.reply('Pour ta sécurité, utilise cette commande en discussion privée avec le bot.');
  if (!c.S.password) return c.reply('Aucun mot de passe n\'est défini sur ce bot.');
  const fails = c.entry.pwFail || (c.entry.pwFail = new Map());
  const f = fails.get(c.num) || { n: 0, t: Date.now() };
  if (f.n >= 5 && Date.now() - f.t < 600000) return c.reply('Trop de tentatives. Réessaie dans 10 minutes.');
  if (hash(c.text) !== c.S.password) { fails.set(c.num, { n: f.n + 1, t: f.n ? f.t : Date.now() }); return c.reply('Mot de passe incorrect.'); }
  fails.delete(c.num);
  if (!c.S.sudo.includes(c.num)) { c.S.sudo.push(c.num); c.S.save(); }
  await c.reply('Mot de passe correct. Tu es maintenant sudo (co-propriétaire) de ce bot.');
});

cmd('setprefix', { level: 'owner', usage: 'setprefix <préfixe>' }, async (c) => {
  const p = c.args[0];
  if (!p || p.length > 3 || /\s/.test(p)) return c.usage(c.prefix + 'setprefix <préfixe de 1 à 3 caractères>');
  c.S.prefix = p; c.S.save();
  await c.reply('Nouveau préfixe : ' + p + '\nExemple : ' + p + 'menu');
});
cmd('delprefix', { level: 'owner' }, async (c) => {
  c.S.prefix = '.'; c.S.save();
  await c.reply('Préfixe personnalisé supprimé. Le préfixe par défaut est : .');
});

// ---- Profil du bot ----
async function setBotPhoto(c) {
  const md = await c.media(['image']);
  if (!md) return c.reply('Envoie ou cite une image avec ' + c.prefix + c.cmd + '.');
  await c.sock.updateProfilePicture(c.entry.sock.user.id, md.buffer);
  await c.reply('Photo de profil du bot mise à jour.');
}
cmd('setpp', { level: 'owner', usage: 'setpp (en répondant à une image)' }, setBotPhoto);
cmd('setbotbio', { level: 'owner', usage: 'setbotbio <texte>' }, async (c) => {
  if (!c.text) return c.usage(c.prefix + 'setbotbio <texte>');
  await c.sock.updateProfileStatus(c.text);
  await c.reply('Bio du bot mise à jour.');
});
cmd('autobio', { level: 'owner', usage: 'autobio <on|off|set <texte>>' }, async (c) => {
  const sub = (c.args[0] || '').toLowerCase();
  if (sub === 'set') {
    const t = c.args.slice(1).join(' ');
    if (!t) return c.usage(c.prefix + 'autobio set <texte>');
    c.S.autobio.text = t; c.S.save();
    return c.reply('Texte de la bio automatique : ' + t + '\nL\'heure est ajoutée à la fin.');
  }
  const v = U.onoff(sub);
  if (v === null) return c.reply(U.box('Bio automatique', ['État : ' + stateTxt(c.S.autobio.on), 'Texte : ' + c.S.autobio.text, 'Utilisation : ' + c.prefix + 'autobio <on|off|set <texte>>']));
  c.S.autobio.on = v; c.S.save();
  if (v) { try { await c.sock.updateProfileStatus(c.S.autobio.text + ' | ' + U.nowParts().hhmm); } catch (e) { /* ignore */ } }
  await c.reply('Bio automatique : ' + stateTxt(v));
});

// ---- Interrupteurs ----
function toggle(name, key, label, extra) {
  cmd(name, { level: 'owner', usage: name + ' <on|off>' }, async (c) => {
    const v = U.onoff(c.args[0]);
    if (v === null) return c.reply(U.box(label, ['État : ' + stateTxt(c.S[key]), 'Utilisation : ' + c.prefix + name + ' <on|off>']));
    c.S[key] = v;
    if (extra) await extra(c, v);
    c.S.save();
    await c.reply(label + ' : ' + stateTxt(v));
  });
}
toggle('autostatus', 'autostatus', 'Visionnage automatique des statuts');
toggle('autotyping', 'autotyping', 'Simulation de saisie', (c, v) => { if (v) c.S.autorecording = false; });
toggle('autorecording', 'autorecording', 'Simulation d\'enregistrement vocal', (c, v) => { if (v) c.S.autotyping = false; });
toggle('autoreact', 'autoreact', 'Réaction automatique');
toggle('anticall', 'anticall', 'Blocage des appels');
toggle('antideletestatus', 'antideletestatus', 'Conservation des statuts supprimés');
toggle('chatbot', 'chatbot', 'Réponse automatique par IA');
cmd('antidelete', { level: 'owner', usage: 'antidelete <on|owner|off>' }, async (c) => {
  const a = (c.args[0] || '').toLowerCase();
  const m = { on: 'chat', chat: 'chat', owner: 'owner', proprietaire: 'owner', off: 'off', non: 'off' }[a];
  if (!m) return c.reply(U.box('Anti-suppression', ['État : ' + (c.S.antidelete === 'off' ? 'désactivé' : c.S.antidelete === 'owner' ? 'envoi au propriétaire' : 'dans la discussion'), 'Utilisation : ' + c.prefix + 'antidelete <on|owner|off>', 'on : le message supprimé est renvoyé dans la discussion', 'owner : il est renvoyé uniquement au propriétaire']));
  c.S.antidelete = m; c.S.save();
  await c.reply('Anti-suppression : ' + (m === 'off' ? 'désactivé' : m === 'owner' ? 'actif, envoi au propriétaire' : 'actif, envoi dans la discussion'));
});

// ---- Sudo, blocage, bannissement ----
const targetNum = (c) => { const t = c.target(); return t ? U.jidNum(t) : null; };
cmd('addsudo', { level: 'owner', usage: 'addsudo @membre' }, async (c) => {
  const n = targetNum(c);
  if (!n) return c.usage(c.prefix + 'addsudo @membre (ou en répondant à son message)');
  if (!c.S.sudo.includes(n)) c.S.sudo.push(n);
  c.S.save();
  await c.reply('@' + n + ' est maintenant sudo.', [U.toJid(n)]);
});
cmd('delsudo', { level: 'owner', usage: 'delsudo @membre' }, async (c) => {
  const n = targetNum(c);
  if (!n) return c.usage(c.prefix + 'delsudo @membre');
  c.S.sudo = c.S.sudo.filter((x) => x !== n); c.S.save();
  await c.reply('@' + n + ' n\'est plus sudo.', [U.toJid(n)]);
});
cmd('sudolist', { level: 'owner' }, async (c) => {
  await c.reply(U.box('Liste des sudo', c.S.sudo.length ? c.S.sudo.map((n, i) => (i + 1) + '. @' + n) : ['Aucun sudo défini.']), c.S.sudo.map(U.toJid));
});
async function blockAct(c, act) {
  let t = c.target();
  if (!t && !c.isGroup) t = c.jid;
  if (!t) return c.usage(c.prefix + c.cmd + ' @membre');
  await c.sock.updateBlockStatus(t, act);
  await c.reply('@' + U.jidNum(t) + (act === 'block' ? ' est bloqué.' : ' est débloqué.'), [t]);
}
cmd('block', { level: 'owner', usage: 'block <numéro|@membre>' }, (c) => blockAct(c, 'block'));
cmd('unblock', { level: 'owner', usage: 'unblock <numéro|@membre>' }, (c) => blockAct(c, 'unblock'));
cmd('ban', { level: 'owner', usage: 'ban @membre' }, async (c) => {
  const n = targetNum(c);
  if (!n) return c.usage(c.prefix + 'ban @membre');
  if (n === c.entry.id) return c.reply('Impossible de bannir le propriétaire.');
  if (!c.S.banned.includes(n)) c.S.banned.push(n);
  c.S.save();
  await c.reply('@' + n + ' est banni : le bot ignorera ses messages.', [U.toJid(n)]);
});
cmd('unban', { level: 'owner', usage: 'unban @membre' }, async (c) => {
  const n = targetNum(c);
  if (!n) return c.usage(c.prefix + 'unban @membre');
  c.S.banned = c.S.banned.filter((x) => x !== n); c.S.save();
  await c.reply('@' + n + ' n\'est plus banni.', [U.toJid(n)]);
});

// ---- Sauvegarde, programmation, maintenance ----
cmd('save', { level: 'owner', usage: 'save (en répondant à un message)' }, async (c) => {
  const q = getQuoted(c);
  if (!q) return c.usage(c.prefix + 'save (en répondant au message à sauvegarder)');
  await c.entry.rawSend(H.selfJid(c.entry), { forward: q, force: true });
  await c.reply('Message sauvegardé dans ta conversation personnelle.');
});
cmd('schedulestatus', { level: 'owner', usage: 'schedulestatus <HH:MM|+30m> <texte>' }, async (c) => {
  const at = U.parseWhen(c.args[0]);
  const text = c.args.slice(1).join(' ');
  if (!at || !text) return c.usage(c.prefix + 'schedulestatus <HH:MM ou +30m> <texte du statut>');
  c.S.jobs.push({ id: Date.now().toString(36), type: 'status', at, text }); c.S.save();
  await c.reply('Statut programmé pour le ' + new Date(at).toLocaleString('fr-FR', { timeZone: cfg.TZ }) + '.');
});
cmd('clearsession', { level: 'owner' }, async (c) => {
  const id = c.entry.id;
  let n = 0;
  if (c.entry.manager.authCol) {
    const r = await c.entry.manager.authCol.deleteMany({ _id: { $regex: '^' + id + ':(pre-key|sender-key)-' } });
    n = r.deletedCount;
  } else {
    const dir = path.join(cfg.DATA, 'sessions', id);
    if (fs.existsSync(dir)) for (const f of fs.readdirSync(dir)) if (/^(pre-key|sender-key)-/.test(f)) { fs.unlinkSync(path.join(dir, f)); n++; }
  }
  await c.reply('Session nettoyée : ' + n + ' fichier(s) de clés temporaires supprimé(s). La connexion reste active.');
});
cmd('cleartmp', { level: 'owner' }, async (c) => {
  let n = 0, size = 0;
  for (const f of fs.readdirSync(cfg.TMP)) { try { const p = path.join(cfg.TMP, f); size += fs.statSync(p).size; fs.unlinkSync(p); n++; } catch (e) { /* ignore */ } }
  await c.reply('Fichiers temporaires supprimés : ' + n + ' (' + U.fmtBytes(size) + ').');
});
cmd('pair', { level: 'owner', usage: 'pair <numéro>' }, async (c) => {
  const n = (c.args[0] || '').replace(/\D/g, '');
  if (!n) return c.usage(c.prefix + 'pair <numéro international sans +>');
  const code = await c.entry.manager.pair(n);
  await c.reply(U.box('Code d\'appairage pour +' + n, [code.match(/.{1,4}/g).join('-'), 'WhatsApp > Appareils connectés > Connecter un appareil > Lier avec un numéro de téléphone.', 'Le code est valable environ 3 minutes.']));
});
cmd('checkidch', { level: 'owner', usage: 'checkidch <lien de la chaîne>' }, async (c) => {
  const m = c.text.match(/whatsapp\.com\/channel\/([\w-]+)/i);
  if (!m) return c.usage(c.prefix + 'checkidch https://whatsapp.com/channel/xxxx');
  const meta = await c.sock.newsletterMetadata('invite', m[1]);
  await c.reply(U.box('Chaîne WhatsApp', ['Nom : ' + meta.name, 'ID : ' + meta.id, 'Abonnés : ' + (meta.subscribers || 'inconnu')]));
});

// ---- Gestion des discussions ----
const lastMsgs = (c) => [{ key: c.m.key, messageTimestamp: nowSec() }];
cmd('archive', { level: 'owner' }, async (c) => { await c.sock.chatModify({ archive: true, lastMessages: lastMsgs(c) }, c.jid); await c.reply('Discussion archivée.'); });
cmd('unarchive', { level: 'owner' }, async (c) => { await c.sock.chatModify({ archive: false, lastMessages: lastMsgs(c) }, c.jid); await c.reply('Discussion désarchivée.'); });
cmd('chatpin', { level: 'owner' }, async (c) => { await c.sock.chatModify({ pin: true }, c.jid); await c.reply('Discussion épinglée.'); });
cmd('unpin', { level: 'owner' }, async (c) => { await c.sock.chatModify({ pin: false }, c.jid); await c.reply('Discussion désépinglée.'); });
cmd('markread', { level: 'owner' }, async (c) => { await c.sock.chatModify({ markRead: true, lastMessages: lastMsgs(c) }, c.jid); await c.reply('Discussion marquée comme lue.'); });
cmd('markunread', { level: 'owner' }, async (c) => { await c.sock.chatModify({ markRead: false, lastMessages: lastMsgs(c) }, c.jid); await c.reply('Discussion marquée comme non lue.'); });
cmd('unmutechat', { level: 'owner' }, async (c) => { await c.sock.chatModify({ mute: null }, c.jid); await c.reply('Notifications réactivées pour cette discussion.'); });

// ---- Profils ----
cmd('profilename', { level: 'owner', usage: 'profilename @membre' }, async (c) => {
  const t = c.target() || (!c.isGroup ? c.jid : null);
  if (!t) return c.usage(c.prefix + 'profilename @membre');
  await c.reply(U.box('Profil', ['Nom : ' + (c.entry.names[U.jidNum(t)] || 'inconnu (la personne doit avoir écrit récemment)'), 'Numéro : +' + U.jidNum(t)]));
});
cmd('fullphoto', { level: 'owner', usage: 'fullphoto @membre' }, async (c) => {
  const t = c.target() || (!c.isGroup ? c.jid : c.sender);
  await ppSend(c, t, '+' + U.jidNum(t));
});
cmd('mypp', {}, async (c) => { await ppSend(c, c.sender, 'toi'); });
cmd('removephoto', { level: 'owner' }, async (c) => { await c.sock.removeProfilePicture(c.entry.sock.user.id); await c.reply('Photo de profil du bot supprimée.'); });
cmd('mystatus', { level: 'owner' }, async (c) => {
  const list = [...c.entry.msgs.values()].filter((m) => m.key.remoteJid === 'status@broadcast' && m.key.fromMe);
  if (!list.length) return c.reply('Aucun statut personnel récent n\'a été enregistré depuis le démarrage du bot.');
  await c.entry.rawSend(c.jid, { forward: list[list.length - 1], force: true }, { quoted: c.m });
  await c.reply('Dernier statut enregistré renvoyé (' + list.length + ' statut(s) en mémoire).');
});

// ---- Groupes et messages ----
cmd('join', { level: 'owner', usage: 'join <lien d\'invitation>' }, async (c) => {
  const m = c.text.match(/chat\.whatsapp\.com\/([A-Za-z0-9]+)/);
  if (!m) return c.usage(c.prefix + 'join https://chat.whatsapp.com/xxxx');
  const id = await c.sock.groupAcceptInvite(m[1]);
  await c.reply('Le bot a rejoint le groupe : ' + id);
});
cmd('listgc', { level: 'owner' }, async (c) => {
  const all = Object.values(await c.sock.groupFetchAllParticipating());
  if (!all.length) return c.reply('Le bot n\'est dans aucun groupe.');
  const lines = all.slice(0, 40).map((g, i) => (i + 1) + '. ' + g.subject + ' - ' + g.participants.length + ' membres\n   ' + g.id);
  if (all.length > 40) lines.push('... et ' + (all.length - 40) + ' autres.');
  await c.reply(U.box('Groupes du bot (' + all.length + ')', lines));
});
cmd('edit', { level: 'owner', usage: 'edit <nouveau texte> (en répondant à un message du bot)' }, async (c) => {
  if (!c.quoted || !c.quoted.key.fromMe) return c.reply('Réponds à un message envoyé par le bot pour le modifier.\nUtilisation : ' + c.prefix + 'edit <nouveau texte>');
  if (!c.text) return c.usage(c.prefix + 'edit <nouveau texte>');
  await c.sock.sendMessage(c.jid, { text: c.text + '\n\n' + cfg.SIGNATURE, edit: c.quoted.key });
});
cmd('forward', { level: 'owner', usage: 'forward <numéro|jid> (en répondant à un message)' }, async (c) => {
  const q = getQuoted(c);
  const a = c.args[0] || '';
  if (!q || !a) return c.usage(c.prefix + 'forward <numéro ou jid> (en répondant au message à transférer)');
  const to = a.includes('@') ? a : U.toJid(a);
  await c.entry.rawSend(to, { forward: q, force: true });
  await c.reply('Message transféré à ' + to + '.');
});
cmd('read', { level: 'owner', usage: 'read (en répondant à un message)' }, async (c) => {
  if (!c.quoted) return c.usage(c.prefix + 'read (en répondant à un message)');
  await c.sock.readMessages([c.quoted.key]);
  await c.reply('Message marqué comme lu.');
});
cmd('groupadd', { level: 'owner', group: true, botAdmin: true, usage: 'groupadd <numéro>' }, async (c) => {
  const nums = c.args.map((a) => a.replace(/\D/g, '')).filter((a) => a.length >= 8);
  if (!nums.length) return c.usage(c.prefix + 'groupadd <numéro international sans +>');
  const res = await c.sock.groupParticipantsUpdate(c.jid, nums.map(U.toJid), 'add');
  await c.reply(U.box('Ajout au groupe', res.map((r) => '+' + U.jidNum(r.jid || r.content && r.content.attrs && r.content.attrs.jid || '') + ' : ' + (String(r.status) === '200' ? 'ajouté' : 'échec (code ' + r.status + ')'))));
});

// ---- Vie privée ----
const P4 = ['all', 'contacts', 'contact_blacklist', 'none'];
const PRIV = {
  lastseen: ['updateLastSeenPrivacy', P4, 'Vu à'],
  online: ['updateOnlinePrivacy', ['all', 'match_last_seen'], 'En ligne'],
  photo: ['updateProfilePicturePrivacy', P4, 'Photo de profil'],
  status: ['updateStatusPrivacy', P4, 'Statuts'],
  read: ['updateReadReceiptsPrivacy', ['all', 'none'], 'Confirmations de lecture'],
  groupadd: ['updateGroupsAddPrivacy', ['all', 'contacts', 'contact_blacklist'], 'Ajout aux groupes'],
};
const VAL_ALIAS = { tous: 'all', tout: 'all', everyone: 'all', contacts: 'contacts', exceptblacklist: 'contact_blacklist', sauf: 'contact_blacklist', personne: 'none', aucun: 'none', nobody: 'none', same: 'match_last_seen', identique: 'match_last_seen' };
async function setPrivacy(c, key, val) {
  const [fn, allowed, label] = PRIV[key];
  val = VAL_ALIAS[val] || val;
  if (!allowed.includes(val)) return c.reply(U.box(label, ['Valeurs possibles : ' + allowed.join(', '), 'Utilisation : ' + c.prefix + (c.cmd === 'privacy' ? 'privacy ' + key : c.cmd) + ' <valeur>']));
  await c.sock[fn](val);
  await c.reply(label + ' : ' + val);
}
cmd('lastseen', { level: 'owner', usage: 'lastseen <all|contacts|contact_blacklist|none>' }, (c) => setPrivacy(c, 'lastseen', (c.args[0] || '').toLowerCase()));
cmd('getprivacy', { level: 'owner' }, async (c) => {
  const p = await c.sock.fetchPrivacySettings(true);
  await c.reply(U.box('Réglages de confidentialité', Object.keys(p).map((k) => k + ' : ' + p[k])));
});
cmd('privacy', { level: 'owner', usage: 'privacy <lastseen|online|photo|status|read|groupadd> <valeur>' }, async (c) => {
  const key = (c.args[0] || '').toLowerCase();
  if (!PRIV[key]) {
    return c.reply(U.box('Menu vie privée', Object.keys(PRIV).map((k) => c.prefix + 'privacy ' + k + ' <' + PRIV[k][1].join('|') + '> : ' + PRIV[k][2]).concat(['Voir les réglages actuels : ' + c.prefix + 'getprivacy'])));
  }
  await setPrivacy(c, key, (c.args[1] || '').toLowerCase());
});

module.exports = { ppSend, getQuoted, setBotPhoto, toggle };
