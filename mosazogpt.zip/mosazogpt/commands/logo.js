'use strict';
const { cmd } = require('../lib/registry');
const ai = require('../lib/ai');
const U = require('../lib/util');
const T = require('../lib/textfx');

cmd('fancy', { usage: 'fancy <texte>' }, async (c) => {
  if (!c.text) return c.usage(c.prefix + 'fancy <texte>');
  await c.reply(U.box('Styles de texte', Object.keys(T.styles).map((k) => k + ' : ' + T.styles[k](c.text)).concat(['petites capitales : ' + T.smallcaps(c.text)])));
});

const STYLES = {
  metallic: 'polished chrome metallic 3D letters, reflections', ice: 'frozen ice crystal letters, frost, blue glow',
  snow: 'snow covered letters, winter, white and blue', impressive: 'impressive golden 3D letters, dramatic light, epic',
  matrix: 'green digital matrix code rain letters, black background', neon: 'bright neon sign letters, glowing tubes, dark wall',
  light: 'glowing light bulbs letters, warm bright light', devil: 'devil horns letters, red flames, dark and sinister',
  purple: 'purple glowing 3D letters, violet gradient', thunder: 'lightning thunder electric letters, storm sky',
  leaves: 'letters made of green leaves, nature, forest', '1917': 'vintage war style letters, sepia, 1917 cinematic typography',
  arena: 'esports arena gaming logo, bold letters, dramatic spotlights', hacker: 'hacker style anonymous logo, green terminal letters, dark',
  sand: 'letters written in desert sand, beach, sunlight', blackpink: 'pink and black stylish logo, glam, bold',
  glitch: 'glitch effect letters, RGB split, digital distortion', fire: 'burning fire flame letters, embers, dark background',
  slice: 'sliced cut letters, sharp, bold color', glow: 'soft glowing letters, bokeh, night', glitch1: 'cyberpunk glitch letters, pink and cyan',
  steal: 'graffiti stealth logo, dark urban', avenger: 'superhero team emblem style letters, heroic metallic',
  marvel: 'comic book hero style 3D letters, red and gold', glitch2: 'retro VHS glitch letters, scanlines', grafiti: 'colorful graffiti street art letters on a wall',
};
for (let i = 1; i <= 12; i++) STYLES[i === 1 ? 'gfx' : 'gfx' + i] = ['bold gaming logo with mascot', 'esports clan emblem, shield', 'minimal modern geometric logo', 'cyberpunk neon gaming logo', 'dragon fantasy emblem logo', 'skull gaming logo, dark', 'wolf mascot gaming logo', 'futuristic chrome 3D logo', 'retro synthwave logo, sunset grid', 'anime style bold logo', 'luxury gold and black logo', 'colorful 3D cartoon logo'][i - 1];
for (const name of Object.keys(STYLES)) {
  cmd(name, { usage: name + ' <texte>' }, async (c) => {
    if (!c.text) return c.usage(c.prefix + name + ' <texte du logo>');
    const prompt = 'logo design with the text "' + c.text.slice(0, 30) + '", ' + STYLES[name] + ', centered, high quality, clean text';
    await c.reply('Création du logo (' + name + ') en cours...');
    await c.sendMedia('image', await U.getBuf(ai.imageUrl(prompt, 'flux'), { timeout: 120000 }), 'Logo : ' + c.text + '\nEffet : ' + name);
  });
}
