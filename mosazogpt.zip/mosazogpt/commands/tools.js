'use strict';
const os = require('os');
const crypto = require('crypto');
const B = require('@whiskeysockets/baileys');
const { cmd } = require('../lib/registry');
const cfg = require('../lib/config');
const U = require('../lib/util');
const M = require('../lib/media');
const H = require('../lib/handler');
const T = require('../lib/textfx');
const Y = require('../lib/ytdlp');
const { upload } = require('../lib/upload');
const fs = require('fs');

const dec = (s) => String(s).replace(/<!\[CDATA\[|\]\]>/g, '').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, '\'');
const strip = (h) => dec(h.replace(/<[^>]+>/g, ' ')).replace(/\s+/g, ' ').trim();
async function ddg(q) {
  const html = await U.getText('https://html.duckduckgo.com/html/?q=' + encodeURIComponent(q));
  const out = [];
  const re = /<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>(.*?)<\/a>[\s\S]*?class="result__snippet"[^>]*>([\s\S]*?)<\/a>/g;
  let m;
  while ((m = re.exec(html)) && out.length < 5) {
    let href = m[1];
    const u = href.match(/uddg=([^&]+)/);
    if (u) href = decodeURIComponent(u[1]);
    out.push({ title: strip(m[2]), url: href, snippet: strip(m[3]) });
  }
  return out;
}
const needText = (c, name, ex) => (c.text ? c.text : (c.usage(c.prefix + name + ' ' + ex), null));

// ---- Vue unique ----
async function viewOnce(c, personal) {
  if (!c.quoted) return c.reply('Réponds à un média en vue unique avec ' + c.prefix + c.cmd + '.');
  const stored = c.entry.msgs.get(c.quoted.id);
  let md = null;
  for (const src of [stored && stored.message, c.quoted.message]) {
    if (!src || md) continue;
    const n = B.normalizeMessageContent(src);
    for (const [k, t] of [['imageMessage', 'image'], ['videoMessage', 'video'], ['audioMessage', 'audio']]) {
      if (n && n[k]) { try { md = { type: t, content: n[k], buffer: await M.dl(n[k], t) }; break; } catch (e) { /* source suivante */ } }
    }
  }
  if (!md) return c.reply('Impossible de récupérer ce média (déjà expiré, ou non reçu par le bot).');
  const to = personal ? H.selfJid(c.entry) : c.jid;
  const cap = 'Média vue unique récupéré' + (md.content.caption ? '\nLégende : ' + md.content.caption : '');
  const extra = md.type === 'audio' ? { mimetype: md.content.mimetype || 'audio/mp4', ptt: !!md.content.ptt } : md.type === 'video' ? { mimetype: 'video/mp4' } : {};
  await c.entry.media(to, md.type, md.buffer, cap, { quoted: personal ? undefined : c.m, extra });
  if (personal) await c.reply('Média vue unique envoyé dans ta conversation personnelle.');
}
cmd('vv', { level: 'owner', usage: 'vv (en répondant à un média vue unique)' }, (c) => viewOnce(c, false));
cmd('vv2', { level: 'owner', usage: 'vv2 (en répondant à un média vue unique)' }, (c) => viewOnce(c, true));

// ---- Web ----
cmd(['ss', 'ssweb'], { usage: 'ss <lien>' }, async (c) => {
  if (!U.isUrl(c.args[0])) return c.usage(c.prefix + 'ss https://exemple.com');
  await c.sendMedia('image', await U.getBuf('https://image.thum.io/get/width/1280/crop/900/' + c.args[0], { timeout: 60000 }), 'Capture de : ' + c.args[0]);
});
cmd(['translate', 'tr'], { usage: 'translate <langue> <texte>' }, async (c) => {
  const q = c.quoted && (c.quoted.message.conversation || (c.quoted.message.extendedTextMessage && c.quoted.message.extendedTextMessage.text));
  const to = (c.args[0] || '').toLowerCase();
  const text = c.args.length > 1 ? c.args.slice(1).join(' ') : q;
  if (!/^[a-z]{2}(-[a-z]{2,4})?$/.test(to) || !text) return c.usage(c.prefix + 'translate <code langue, ex : en, es, fr, hi> <texte> (ou en répondant à un message)');
  await c.reply(U.box('Traduction (' + to + ')', [await U.translate(text, to)]));
});
cmd(['qrcode', 'qr', 'qmaker'], { usage: 'qrcode <texte ou lien>' }, async (c) => {
  if (!c.text) return c.usage(c.prefix + 'qrcode <texte ou lien>');
  await c.sendMedia('image', await require('qrcode').toBuffer(c.text, { width: 512, margin: 2 }), 'QR code : ' + c.text.slice(0, 100));
});
cmd('readqr', { usage: 'readqr (en répondant à une image)' }, async (c) => {
  const md = await c.media(['image']);
  if (!md) return c.reply('Envoie ou cite une image contenant un QR code.');
  const Jimp = require('jimp'), jsQR = require('jsqr');
  const img = await Jimp.read(md.buffer);
  const r = jsQR(new Uint8ClampedArray(img.bitmap.data), img.bitmap.width, img.bitmap.height);
  await c.reply(r ? U.box('Contenu du QR code', [r.data]) : 'Aucun QR code lisible dans cette image.');
});
cmd(['shorturl', 'urlshortener'], { usage: 'shorturl <lien>' }, async (c) => {
  if (!U.isUrl(c.args[0])) return c.usage(c.prefix + 'shorturl https://lien-tres-long.com');
  let s;
  try { s = (await U.getText('https://is.gd/create.php?format=simple&url=' + encodeURIComponent(c.args[0]))).trim(); } catch (e) { s = (await U.getText('https://tinyurl.com/api-create.php?url=' + encodeURIComponent(c.args[0]))).trim(); }
  await c.reply(U.box('Lien raccourci', [s]));
});
cmd('paste', { usage: 'paste <texte>' }, async (c) => {
  const t = c.text || (c.quoted && (c.quoted.message.conversation || (c.quoted.message.extendedTextMessage && c.quoted.message.extendedTextMessage.text)));
  if (!t) return c.usage(c.prefix + 'paste <texte>');
  const url = (await U.getText('https://paste.rs', { method: 'POST', body: t })).trim();
  await c.reply(U.box('Texte publié', [url]));
});
cmd('google', { usage: 'google <recherche>' }, async (c) => {
  if (!needText(c, 'google', '<recherche>')) return;
  const r = await ddg(c.text);
  await c.reply(U.box('Résultats pour : ' + c.text, r.length ? r.map((x, i) => (i + 1) + '. ' + x.title + '\n   ' + x.snippet.slice(0, 160) + '\n   ' + x.url) : ['Aucun résultat.']));
});
cmd('wattpad', { usage: 'wattpad <recherche>' }, async (c) => {
  if (!needText(c, 'wattpad', '<recherche>')) return;
  const r = (await ddg('site:wattpad.com ' + c.text)).filter((x) => /wattpad\.com/.test(x.url));
  await c.reply(U.box('Wattpad : ' + c.text, r.length ? r.map((x, i) => (i + 1) + '. ' + x.title + '\n   ' + x.url) : ['Aucun résultat.']));
});
cmd('image', { usage: 'image <recherche>' }, async (c) => {
  if (!needText(c, 'image', '<recherche>')) return;
  const j = await U.getJSON('https://commons.wikimedia.org/w/api.php?action=query&format=json&generator=search&gsrnamespace=6&gsrlimit=8&prop=imageinfo&iiprop=url|mime&iiurlwidth=1024&gsrsearch=' + encodeURIComponent(c.text));
  const p = j.query && Object.values(j.query.pages).filter((x) => x.imageinfo && /^image\/(jpeg|png)/.test(x.imageinfo[0].mime));
  if (!p || !p.length) return c.reply('Aucune image trouvée pour : ' + c.text);
  const x = U.pick(p);
  await c.sendMedia('image', await U.getBuf(x.imageinfo[0].thumburl || x.imageinfo[0].url), 'Image : ' + c.text + '\nSource : Wikimedia Commons');
});
cmd('wiki', { usage: 'wiki <sujet>' }, async (c) => {
  if (!needText(c, 'wiki', '<sujet>')) return;
  const lang = { fr: 'fr', en: 'en', es: 'es', hi: 'hi' }[c.S.lang] || 'fr';
  const s = await U.getJSON('https://' + lang + '.wikipedia.org/w/api.php?action=opensearch&format=json&limit=1&search=' + encodeURIComponent(c.text));
  if (!s[1] || !s[1][0]) return c.reply('Aucun article trouvé.');
  const j = await U.getJSON('https://' + lang + '.wikipedia.org/api/rest_v1/page/summary/' + encodeURIComponent(s[1][0]));
  await c.reply(U.box('Wikipédia : ' + j.title, [String(j.extract || '').slice(0, 900), 'Article : ' + (j.content_urls && j.content_urls.desktop.page)]));
});
cmd('define', { usage: 'define <mot>' }, async (c) => {
  if (!needText(c, 'define', '<mot>')) return;
  const lang = { fr: 'fr', en: 'en', es: 'es', hi: 'hi' }[c.S.lang] || 'fr';
  const j = await U.getJSON('https://api.dictionaryapi.dev/api/v2/entries/' + lang + '/' + encodeURIComponent(c.args[0]), { allowError: true });
  if (!Array.isArray(j)) return c.reply('Aucune définition trouvée pour : ' + c.args[0]);
  const lines = [];
  for (const m of j[0].meanings.slice(0, 3)) lines.push(m.partOfSpeech + ' : ' + m.definitions[0].definition);
  await c.reply(U.box('Définition : ' + j[0].word, lines));
});
cmd('npm', { usage: 'npm <paquet>' }, async (c) => {
  if (!needText(c, 'npm', '<paquet>')) return;
  const j = await U.getJSON('https://registry.npmjs.org/-/v1/search?size=5&text=' + encodeURIComponent(c.text));
  await c.reply(U.box('Paquets NPM', j.objects.length ? j.objects.map((o, i) => (i + 1) + '. ' + o.package.name + ' ' + o.package.version + '\n   ' + (o.package.description || '').slice(0, 100) + '\n   ' + o.package.links.npm) : ['Aucun résultat.']));
});
cmd('netflix', { usage: 'netflix <titre>' }, async (c) => {
  if (!needText(c, 'netflix', '<titre>')) return;
  const j = await U.getJSON('https://api.tvmaze.com/search/shows?q=' + encodeURIComponent(c.text));
  const l = j.slice(0, 3).map((x, i) => (i + 1) + '. ' + x.show.name + ' (' + String(x.show.premiered || '?').slice(0, 4) + ') - ' + (x.show.genres || []).join(', ') + '\n   ' + strip(x.show.summary || '').slice(0, 160));
  await c.reply(U.box('Séries trouvées', [...(l.length ? l : ['Aucune série trouvée.']), 'Vérifier la disponibilité sur Netflix : https://www.netflix.com/search?q=' + encodeURIComponent(c.text)]));
});
cmd('imdb', { usage: 'imdb <titre du film>' }, async (c) => {
  if (!needText(c, 'imdb', '<titre>')) return;
  if (!cfg.OMDB_KEY) return c.reply('Clé OMDB_KEY non configurée (gratuite sur omdbapi.com/apikey.aspx).');
  const j = await U.getJSON('https://www.omdbapi.com/?apikey=' + cfg.OMDB_KEY + '&plot=short&t=' + encodeURIComponent(c.text));
  if (j.Response === 'False') return c.reply('Film introuvable.');
  const info = ['Titre : ' + j.Title + ' (' + j.Year + ')', 'Genre : ' + j.Genre, 'Durée : ' + j.Runtime, 'Réalisateur : ' + j.Director, 'Acteurs : ' + j.Actors, 'Note IMDb : ' + j.imdbRating, 'Résumé : ' + j.Plot];
  if (j.Poster && j.Poster !== 'N/A') await c.sendMedia('image', await U.getBuf(j.Poster), U.box('Film', info));
  else await c.reply(U.box('Film', info));
});
cmd('lyrics', { usage: 'lyrics <titre ou artiste - titre>' }, async (c) => {
  if (!needText(c, 'lyrics', '<titre ou artiste - titre>')) return;
  const j = await U.getJSON('https://api.lyrics.ovh/suggest/' + encodeURIComponent(c.text));
  const s = j.data && j.data[0];
  const lines = s ? ['Titre : ' + s.title, 'Artiste : ' + s.artist.name, 'Album : ' + s.album.title] : ['Aucune correspondance exacte.'];
  lines.push('Paroles (site officiel de référence) : https://genius.com/search?q=' + encodeURIComponent(s ? s.artist.name + ' ' + s.title : c.text), 'Le bot ne reproduit pas les paroles protégées par le droit d\'auteur.');
  await c.reply(U.box('Chanson identifiée', lines));
});
cmd('shazam', { usage: 'shazam (en répondant à un audio ou une vidéo)' }, async (c) => {
  if (!cfg.AUDD_TOKEN) return c.reply('Clé AUDD_TOKEN non configurée (essai gratuit sur audd.io).');
  const md = await c.media(['audio', 'video']);
  if (!md) return c.reply('Réponds à un extrait audio ou vidéo.');
  const mp3 = await U.ffmpeg(md.buffer, md.ext, ['-vn', '-t', '20', '-acodec', 'libmp3lame'], 'mp3');
  const fd = new FormData();
  fd.append('api_token', cfg.AUDD_TOKEN); fd.append('file', new Blob([mp3], { type: 'audio/mpeg' }), 'a.mp3');
  const j = await U.getJSON('https://api.audd.io/', { method: 'POST', body: fd, timeout: 60000 });
  if (!j.result) return c.reply('Musique non reconnue.');
  await c.reply(U.box('Musique reconnue', ['Titre : ' + j.result.title, 'Artiste : ' + j.result.artist, 'Album : ' + (j.result.album || 'inconnu')]));
});
cmd('scloud', { usage: 'scloud <recherche>' }, async (c) => {
  if (!needText(c, 'scloud', '<recherche>')) return;
  const r = await U.run(Y.BIN, ['--flat-playlist', '--no-warnings', '--print', '%(title)s | %(webpage_url)s', 'scsearch5:' + c.text], { timeout: 60000 });
  const l = r.stdout.split('\n').filter(Boolean);
  await c.reply(U.box('SoundCloud : ' + c.text, l.length ? l.map((x, i) => (i + 1) + '. ' + x) : ['Aucun résultat (yt-dlp requis).']));
});

// ---- Donnees en direct ----
const WMO = { 0: 'ciel dégagé', 1: 'plutôt dégagé', 2: 'partiellement nuageux', 3: 'couvert', 45: 'brouillard', 48: 'brouillard givrant', 51: 'bruine légère', 53: 'bruine', 55: 'bruine forte', 61: 'pluie faible', 63: 'pluie', 65: 'pluie forte', 71: 'neige faible', 73: 'neige', 75: 'neige forte', 80: 'averses', 81: 'averses fortes', 82: 'averses violentes', 95: 'orage', 96: 'orage avec grêle', 99: 'orage violent avec grêle' };
cmd('weather', { usage: 'weather <ville>' }, async (c) => {
  if (!needText(c, 'weather', '<ville>')) return;
  const g = await U.getJSON('https://geocoding-api.open-meteo.com/v1/search?count=1&language=fr&name=' + encodeURIComponent(c.text));
  const p = g.results && g.results[0];
  if (!p) return c.reply('Ville introuvable : ' + c.text);
  const w = (await U.getJSON('https://api.open-meteo.com/v1/forecast?latitude=' + p.latitude + '&longitude=' + p.longitude + '&current=temperature_2m,apparent_temperature,relative_humidity_2m,wind_speed_10m,weather_code&daily=temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=1')).current;
  const d = (await U.getJSON('https://api.open-meteo.com/v1/forecast?latitude=' + p.latitude + '&longitude=' + p.longitude + '&daily=temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=1')).daily;
  await c.reply(U.box('Météo : ' + p.name + (p.country ? ', ' + p.country : ''), ['Conditions : ' + (WMO[w.weather_code] || 'inconnues'), 'Température : ' + w.temperature_2m + ' °C (ressentie ' + w.apparent_temperature + ' °C)', 'Aujourd\'hui : min ' + d.temperature_2m_min[0] + ' °C, max ' + d.temperature_2m_max[0] + ' °C', 'Humidité : ' + w.relative_humidity_2m + ' %', 'Vent : ' + w.wind_speed_10m + ' km/h']));
});
cmd('news', { usage: 'news [sujet]' }, async (c) => {
  const url = c.text ? 'https://news.google.com/rss/search?hl=fr&gl=FR&ceid=FR:fr&q=' + encodeURIComponent(c.text) : 'https://news.google.com/rss?hl=fr&gl=FR&ceid=FR:fr';
  const xml = await U.getText(url);
  const items = [...xml.matchAll(/<item>[\s\S]*?<title>([\s\S]*?)<\/title>[\s\S]*?<link>([\s\S]*?)<\/link>/g)].slice(0, 6);
  await c.reply(U.box('Actualités' + (c.text ? ' : ' + c.text : ''), items.length ? items.map((m, i) => (i + 1) + '. ' + dec(m[1]) + '\n   ' + dec(m[2]).trim()) : ['Aucun article.']));
});
const LEAGUES = { ligue1: 'fra.1', premier: 'eng.1', liga: 'esp.1', seriea: 'ita.1', bundesliga: 'ger.1', ucl: 'uefa.champions' };
cmd('livescore', { usage: 'livescore [ligue1|premier|liga|seriea|bundesliga|ucl]' }, async (c) => {
  const k = (c.args[0] || 'ligue1').toLowerCase();
  if (!LEAGUES[k]) return c.usage(c.prefix + 'livescore [' + Object.keys(LEAGUES).join('|') + ']');
  const j = await U.getJSON('https://site.api.espn.com/apis/site/v2/sports/soccer/' + LEAGUES[k] + '/scoreboard');
  const l = (j.events || []).slice(0, 12).map((e) => { const cp = e.competitions[0].competitors; const h = cp.find((x) => x.homeAway === 'home'), a = cp.find((x) => x.homeAway === 'away'); return h.team.displayName + ' ' + h.score + ' - ' + a.score + ' ' + a.team.displayName + ' (' + e.status.type.shortDetail + ')'; });
  await c.reply(U.box('Scores : ' + k, l.length ? l : ['Aucun match en ce moment.']));
});
const COINS = { btc: 'bitcoin', eth: 'ethereum', sol: 'solana', bnb: 'binancecoin', xrp: 'ripple', doge: 'dogecoin', ada: 'cardano', ltc: 'litecoin', ton: 'the-open-network', usdt: 'tether' };
cmd('crypto', { usage: 'crypto <btc|eth|sol|...>' }, async (c) => {
  const k = (c.args[0] || 'btc').toLowerCase(), id = COINS[k] || k;
  const j = await U.getJSON('https://api.coingecko.com/api/v3/simple/price?ids=' + encodeURIComponent(id) + '&vs_currencies=eur,usd&include_24hr_change=true');
  if (!j[id]) return c.reply('Cryptomonnaie introuvable : ' + k);
  await c.reply(U.box('Cours : ' + id, ['Prix : ' + j[id].eur + ' EUR / ' + j[id].usd + ' USD', 'Variation 24 h : ' + (j[id].eur_24h_change || 0).toFixed(2) + ' %']));
});
cmd('currency', { usage: 'currency <montant> <DEVISE> <DEVISE>' }, async (c) => {
  const amt = parseFloat((c.args[0] || '').replace(',', '.')), from = (c.args[1] || '').toUpperCase(), to = (c.args[2] || '').toUpperCase();
  if (!amt || !from || !to) return c.usage(c.prefix + 'currency 100 EUR USD');
  const j = await U.getJSON('https://open.er-api.com/v6/latest/' + from);
  if (!j.rates || !j.rates[to]) return c.reply('Devise inconnue.');
  await c.reply(U.box('Conversion', [amt + ' ' + from + ' = ' + (amt * j.rates[to]).toFixed(2) + ' ' + to, 'Taux : 1 ' + from + ' = ' + j.rates[to] + ' ' + to]));
});
cmd('reminder', { usage: 'reminder <+10m|+2h|HH:MM> <texte>' }, async (c) => {
  const at = U.parseWhen(c.args[0]), text = c.args.slice(1).join(' ');
  if (!at || !text) return c.usage(c.prefix + 'reminder <+10m | +2h | HH:MM> <texte>');
  c.S.jobs.push({ id: Date.now().toString(36), type: 'msg', at, jid: c.jid, text: 'Rappel : ' + text });
  c.S.save();
  await c.reply('Rappel programmé pour le ' + new Date(at).toLocaleString('fr-FR', { timeZone: cfg.TZ }) + '.');
});
const SIGNS = ['bélier', 'taureau', 'gémeaux', 'cancer', 'lion', 'vierge', 'balance', 'scorpion', 'sagittaire', 'capricorne', 'verseau', 'poissons'];
const HORO = ['Une journée propice aux initiatives.', 'Prends le temps d\'écouter ton entourage.', 'Une bonne nouvelle pourrait arriver.', 'Reste prudent dans tes dépenses.', 'Ta créativité est en pleine forme.', 'Un moment de repos te fera du bien.', 'Une rencontre inattendue est possible.', 'Concentre-toi sur un objectif à la fois.'];
cmd('horo', { usage: 'horo <signe>' }, async (c) => {
  const s = (c.args[0] || '').toLowerCase().replace('é', 'e').replace('è', 'e');
  const sign = SIGNS.find((x) => x.replace('é', 'e').replace('è', 'e') === s);
  if (!sign) return c.usage(c.prefix + 'horo <' + SIGNS.join('|') + '>');
  const h = U.hashStr(sign + U.nowParts().date);
  await c.reply(U.box('Horoscope du jour : ' + sign, ['Amour : ' + HORO[h % 8], 'Travail : ' + HORO[(h >> 3) % 8], 'Santé : ' + HORO[(h >> 6) % 8], 'Chiffre chanceux : ' + (h % 9 + 1), 'Cet horoscope est fourni à titre de divertissement.']));
});

// ---- Calcul et encodage ----
cmd(['calculator', 'calc'], { usage: 'calc <expression>' }, async (c) => {
  const e = c.text.replace(/,/g, '.').replace(/\^/g, '**').replace(/x/gi, '*');
  if (!e || !/^[0-9+\-*/().%\s]+$/.test(e)) return c.usage(c.prefix + 'calc 12*(3+4)/2   (opérateurs : + - * / ^ % et parenthèses)');
  let r;
  try { r = Function('"use strict";return (' + e + ')')(); } catch (err) { return c.reply('Expression invalide.'); }
  if (typeof r !== 'number' || !isFinite(r)) return c.reply('Résultat impossible à calculer.');
  await c.reply(U.box('Calcul', [c.text + ' = ' + Math.round(r * 1e10) / 1e10]));
});
cmd('hash', { usage: 'hash [md5|sha1|sha256|sha512] <texte>' }, async (c) => {
  const algo = ['md5', 'sha1', 'sha256', 'sha512'].includes((c.args[0] || '').toLowerCase()) ? c.args[0].toLowerCase() : 'sha256';
  const text = algo === (c.args[0] || '').toLowerCase() ? c.args.slice(1).join(' ') : c.text;
  if (!text) return c.usage(c.prefix + 'hash [md5|sha1|sha256|sha512] <texte>');
  await c.reply(U.box('Empreinte ' + algo, [crypto.createHash(algo).update(text).digest('hex')]));
});
cmd('base64', { usage: 'base64 <enc|dec> <texte>' }, async (c) => {
  const m = (c.args[0] || '').toLowerCase(), t = c.args.slice(1).join(' ');
  if (!['enc', 'dec'].includes(m) || !t) return c.usage(c.prefix + 'base64 <enc|dec> <texte>');
  await c.reply(U.box('Base64', [m === 'enc' ? Buffer.from(t).toString('base64') : Buffer.from(t, 'base64').toString('utf8')]));
});
cmd(['binary', 'binarytotext'], { usage: 'binary <enc|dec> <texte>' }, async (c) => {
  const m = (c.args[0] || '').toLowerCase(), t = c.args.slice(1).join(' ');
  if (!['enc', 'dec'].includes(m) || !t) return c.usage(c.prefix + 'binary <enc|dec> <texte ou binaire>');
  const out = m === 'enc' ? [...Buffer.from(t)].map((b) => b.toString(2).padStart(8, '0')).join(' ') : Buffer.from(t.split(/\s+/).map((b) => parseInt(b, 2))).toString('utf8');
  await c.reply(U.box('Binaire', [out]));
});
const keyOf = (pw, salt) => crypto.scryptSync(pw, salt, 32);
cmd('encrypt', { usage: 'encrypt <mot de passe> <texte>' }, async (c) => {
  const pw = c.args[0], t = c.args.slice(1).join(' ');
  if (!pw || !t) return c.usage(c.prefix + 'encrypt <mot de passe> <texte>');
  const salt = crypto.randomBytes(16), iv = crypto.randomBytes(12);
  const ci = crypto.createCipheriv('aes-256-gcm', keyOf(pw, salt), iv);
  const enc = Buffer.concat([ci.update(t, 'utf8'), ci.final()]);
  await c.reply(U.box('Texte chiffré (AES-256)', [Buffer.concat([salt, iv, ci.getAuthTag(), enc]).toString('base64'), 'Déchiffrement : ' + c.prefix + 'decrypt <mot de passe> <texte chiffré>']));
});
cmd('decrypt', { usage: 'decrypt <mot de passe> <texte chiffré>' }, async (c) => {
  const pw = c.args[0], t = c.args[1];
  if (!pw || !t) return c.usage(c.prefix + 'decrypt <mot de passe> <texte chiffré>');
  try {
    const b = Buffer.from(t, 'base64');
    const d = crypto.createDecipheriv('aes-256-gcm', keyOf(pw, b.subarray(0, 16)), b.subarray(16, 28));
    d.setAuthTag(b.subarray(28, 44));
    await c.reply(U.box('Texte déchiffré', [Buffer.concat([d.update(b.subarray(44)), d.final()]).toString('utf8')]));
  } catch (e) { await c.reply('Déchiffrement impossible : mot de passe ou texte incorrect.'); }
});
cmd('timestamp', { usage: 'timestamp [secondes | AAAA-MM-JJ]' }, async (c) => {
  const a = c.args[0];
  let d = new Date();
  if (a && /^\d{9,13}$/.test(a)) d = new Date(a.length > 11 ? +a : +a * 1000);
  else if (a) { d = new Date(a); if (isNaN(d)) return c.usage(c.prefix + 'timestamp [secondes | AAAA-MM-JJ]'); }
  await c.reply(U.box('Horodatage', ['Timestamp (secondes) : ' + Math.floor(d / 1000), 'Millisecondes : ' + d.getTime(), 'Date (' + cfg.TZ + ') : ' + d.toLocaleString('fr-FR', { timeZone: cfg.TZ }), 'UTC : ' + d.toISOString()]));
});

// ---- Texte ----
cmd('count', { usage: 'count <texte>' }, async (c) => {
  const t = c.text || (c.quoted && (c.quoted.message.conversation || (c.quoted.message.extendedTextMessage && c.quoted.message.extendedTextMessage.text))) || '';
  if (!t) return c.usage(c.prefix + 'count <texte>');
  await c.reply(U.box('Comptage', ['Caractères : ' + t.length, 'Sans espaces : ' + t.replace(/\s/g, '').length, 'Mots : ' + t.split(/\s+/).filter(Boolean).length, 'Lignes : ' + t.split('\n').length]));
});
cmd('reverse', { usage: 'reverse <texte>' }, async (c) => { if (needText(c, 'reverse', '<texte>')) await c.reply(U.box('Texte inversé', [[...c.text].reverse().join('')])); });
cmd('case', { usage: 'case <upper|lower|title|sentence> <texte>' }, async (c) => {
  const m = (c.args[0] || '').toLowerCase(), t = c.args.slice(1).join(' ');
  const f = { upper: (s) => s.toUpperCase(), lower: (s) => s.toLowerCase(), title: (s) => s.toLowerCase().replace(/(^|\s)\S/g, (x) => x.toUpperCase()), sentence: (s) => s.toLowerCase().replace(/(^\s*|[.!?]\s+)(\p{L})/gu, (x, a, b) => a + b.toUpperCase()) }[m];
  if (!f || !t) return c.usage(c.prefix + 'case <upper|lower|title|sentence> <texte>');
  await c.reply(U.box('Casse modifiée', [f(t)]));
});
cmd('palindrome', { usage: 'palindrome <texte>' }, async (c) => {
  if (!needText(c, 'palindrome', '<texte>')) return;
  const s = c.text.toLowerCase().normalize('NFD').replace(/[^a-z0-9]/g, '');
  await c.reply('« ' + c.text + ' » ' + (s && s === [...s].reverse().join('') ? 'est un palindrome.' : 'n\'est pas un palindrome.'));
});
cmd('age', { usage: 'age <JJ/MM/AAAA>' }, async (c) => {
  const m = (c.args[0] || '').match(/^(\d{1,2})[/.-](\d{1,2})[/.-](\d{4})$/);
  if (!m) return c.usage(c.prefix + 'age 25/12/2000');
  const b = new Date(+m[3], +m[2] - 1, +m[1]), n = new Date();
  if (isNaN(b) || b > n) return c.reply('Date invalide.');
  let y = n.getFullYear() - b.getFullYear(), mo = n.getMonth() - b.getMonth(), d = n.getDate() - b.getDate();
  if (d < 0) { mo--; d += new Date(n.getFullYear(), n.getMonth(), 0).getDate(); }
  if (mo < 0) { y--; mo += 12; }
  await c.reply(U.box('Âge', [y + ' ans, ' + mo + ' mois et ' + d + ' jours', 'Jours vécus : ' + Math.floor((n - b) / 864e5)]));
});
cmd('fliptext', { usage: 'fliptext <texte>' }, async (c) => { if (needText(c, 'fliptext', '<texte>')) await c.reply(U.box('Texte retourné', [T.flip(c.text)])); });
cmd('flip', { usage: 'flip <texte>' }, async (c) => { if (needText(c, 'flip', '<texte>')) await c.reply(U.box('Texte retourné', [T.flip(c.text)])); });
cmd('smallcaps', { usage: 'smallcaps <texte>' }, async (c) => { if (needText(c, 'smallcaps', '<texte>')) await c.reply(U.box('Petites capitales', [T.smallcaps(c.text)])); });
cmd('stext', { usage: 'stext <texte>' }, async (c) => { if (needText(c, 'stext', '<texte>')) await c.reply(U.box('Styles de texte', Object.keys(T.styles).map((k) => T.styles[k](c.text)))); });
cmd('readmore', { usage: 'readmore <texte visible> | <texte caché>' }, async (c) => {
  const [a, b] = c.text.split('|').map((s) => s.trim());
  if (!a || !b) return c.usage(c.prefix + 'readmore <texte visible> | <texte caché>');
  await c.reply(a + String.fromCharCode(8206).repeat(4001) + b);
});

// ---- Messages et appareil ----
cmd('delete', { usage: 'delete (en répondant à un message du bot)' }, async (c) => {
  if (!c.quoted) return c.usage(c.prefix + 'delete (en répondant au message à supprimer)');
  if (!c.quoted.key.fromMe && !(c.isGroup && c.botAdmin && (c.isAdmin || c.isOwner))) return c.reply('Je ne peux supprimer que mes propres messages (ou ceux des autres si je suis administrateur du groupe).');
  await c.sock.sendMessage(c.jid, { delete: c.quoted.key });
});
cmd('savecontact', { usage: 'savecontact @membre' }, async (c) => {
  const t = c.target();
  if (!t) return c.usage(c.prefix + 'savecontact @membre (ou en répondant à son message)');
  const n = U.jidNum(t), name = c.name(t);
  await c.send({ contacts: { displayName: name, contacts: [{ vcard: 'BEGIN:VCARD\nVERSION:3.0\nFN:' + name + '\nTEL;type=CELL;waid=' + n + ':+' + n + '\nEND:VCARD' }] } });
  await c.reply('Fiche contact envoyée : appuie dessus pour enregistrer le contact.');
});
cmd('device', { usage: 'device (en répondant à un message)' }, async (c) => {
  if (!c.quoted) return c.usage(c.prefix + 'device (en répondant à un message)');
  let d = 'inconnu';
  try { d = B.getDevice(c.quoted.id); } catch (e) { d = c.quoted.id.length > 21 ? 'android' : c.quoted.id.startsWith('3A') ? 'ios' : 'web'; }
  await c.reply(U.box('Appareil de l\'expéditeur', ['Plateforme probable : ' + d, 'ID du message : ' + c.quoted.id]));
});
cmd('forwarded', { usage: 'forwarded (en répondant à un message)' }, async (c) => {
  if (!c.quoted) return c.usage(c.prefix + 'forwarded (en répondant à un message)');
  const n = B.normalizeMessageContent(c.quoted.message) || {};
  let ci = null;
  for (const k of Object.keys(n)) if (n[k] && n[k].contextInfo) ci = n[k].contextInfo;
  const f = ci && ci.isForwarded;
  await c.reply(U.box('Transfert', [f ? 'Ce message a été transféré.' + (ci.forwardingScore ? ' Niveau de transfert : ' + ci.forwardingScore : '') : 'Ce message n\'est pas marqué comme transféré (ou l\'information n\'est pas disponible).']));
});
cmd('cpu', { level: 'owner' }, async (c) => {
  const cpus = os.cpus(), mem = process.memoryUsage();
  await c.reply(U.box('Ressources du serveur', ['Processeur : ' + (cpus[0] ? cpus[0].model : 'inconnu') + ' (' + cpus.length + ' coeurs)', 'Charge (1 / 5 / 15 min) : ' + os.loadavg().map((x) => x.toFixed(2)).join(' / '), 'Mémoire système : ' + U.fmtBytes(os.totalmem() - os.freemem()) + ' / ' + U.fmtBytes(os.totalmem()), 'Mémoire du bot : ' + U.fmtBytes(mem.rss), 'Plateforme : ' + os.platform() + ' ' + os.arch(), 'Node.js : ' + process.version]));
});

// ---- Effets photo ----
const EF = {
  mirror: (i) => i.mirror(true, false), flip: (i) => i.mirror(false, true), vintage: (i) => i.sepia().contrast(0.1).brightness(-0.05),
  pixel: (i) => i.pixelate(Math.max(6, Math.round(i.bitmap.width / 60))), poster: (i) => i.posterize(4), rotate: (i) => i.rotate(90), dark: (i) => i.brightness(-0.35), bright: (i) => i.brightness(0.3),
};
cmd('ephoto', { usage: 'ephoto <' + Object.keys(EF).join('|') + '> (en répondant à une image)' }, async (c) => {
  const k = (c.args[0] || '').toLowerCase();
  if (!EF[k]) return c.reply(U.box('Effets photo disponibles', [...Object.keys(EF), 'Utilisation : ' + c.prefix + 'ephoto <effet> (en répondant à une image)']));
  const md = await c.media(['image']);
  if (!md) return c.reply('Envoie ou cite une image.');
  await c.sendMedia('image', await M.jimp(md.buffer, (i) => EF[k](i)), 'Effet : ' + k);
});
cmd('excard', { usage: 'excard [@membre]' }, async (c) => {
  const t = c.target() || c.sender, n = U.jidNum(t);
  let pp = null;
  try { pp = await U.getBuf(await c.sock.profilePictureUrl(t, 'image')); } catch (e) { /* sans photo */ }
  const buf = await M.jimp(fs.readFileSync(cfg.ROOT + '/data/blank.png'), async (img, J) => {
    const card = new J(800, 400, 0x1f2c34ff);
    const f = await J.loadFont(J.FONT_SANS_32_WHITE), f2 = await J.loadFont(J.FONT_SANS_16_WHITE);
    if (pp) { const p = await J.read(pp); p.cover(260, 260).circle(); card.composite(p, 50, 70); }
    card.print(f, 350, 100, c.name(t).slice(0, 22)); card.print(f2, 350, 170, 'Numéro : +' + n); card.print(f2, 350, 200, 'Carte MosazoGPT'); card.print(f2, 350, 330, U.nowParts().date);
    return card;
  });
  await c.sendMedia('image', buf, 'Carte générée.');
});

// ---- Chimie ----
const EL = 'Hydrogène,Hélium,Lithium,Béryllium,Bore,Carbone,Azote,Oxygène,Fluor,Néon,Sodium,Magnésium,Aluminium,Silicium,Phosphore,Soufre,Chlore,Argon,Potassium,Calcium,Scandium,Titane,Vanadium,Chrome,Manganèse,Fer,Cobalt,Nickel,Cuivre,Zinc,Gallium,Germanium,Arsenic,Sélénium,Brome,Krypton,Rubidium,Strontium,Yttrium,Zirconium,Niobium,Molybdène,Technétium,Ruthénium,Rhodium,Palladium,Argent,Cadmium,Indium,Étain,Antimoine,Tellure,Iode,Xénon,Césium,Baryum,Lanthane,Cérium,Praséodyme,Néodyme,Prométhium,Samarium,Europium,Gadolinium,Terbium,Dysprosium,Holmium,Erbium,Thulium,Ytterbium,Lutécium,Hafnium,Tantale,Tungstène,Rhénium,Osmium,Iridium,Platine,Or,Mercure,Thallium,Plomb,Bismuth,Polonium,Astate,Radon,Francium,Radium,Actinium,Thorium,Protactinium,Uranium,Neptunium,Plutonium,Américium,Curium,Berkélium,Californium,Einsteinium,Fermium,Mendélévium,Nobélium,Lawrencium,Rutherfordium,Dubnium,Seaborgium,Bohrium,Hassium,Meitnérium,Darmstadtium,Roentgenium,Copernicium,Nihonium,Flérovium,Moscovium,Livermorium,Tennesse,Oganesson'.split(',');
const SY = 'H,He,Li,Be,B,C,N,O,F,Ne,Na,Mg,Al,Si,P,S,Cl,Ar,K,Ca,Sc,Ti,V,Cr,Mn,Fe,Co,Ni,Cu,Zn,Ga,Ge,As,Se,Br,Kr,Rb,Sr,Y,Zr,Nb,Mo,Tc,Ru,Rh,Pd,Ag,Cd,In,Sn,Sb,Te,I,Xe,Cs,Ba,La,Ce,Pr,Nd,Pm,Sm,Eu,Gd,Tb,Dy,Ho,Er,Tm,Yb,Lu,Hf,Ta,W,Re,Os,Ir,Pt,Au,Hg,Tl,Pb,Bi,Po,At,Rn,Fr,Ra,Ac,Th,Pa,U,Np,Pu,Am,Cm,Bk,Cf,Es,Fm,Md,No,Lr,Rf,Db,Sg,Bh,Hs,Mt,Ds,Rg,Cn,Nh,Fl,Mc,Lv,Ts,Og'.split(',');
cmd('element', { usage: 'element <nom, symbole ou numéro atomique>' }, async (c) => {
  const q = (c.args[0] || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  if (!q) return c.usage(c.prefix + 'element <nom, symbole ou numéro>');
  let i = /^\d+$/.test(q) ? +q - 1 : SY.findIndex((s) => s.toLowerCase() === q);
  if (i < 0) i = EL.findIndex((n) => n.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '') === q);
  if (i < 0 || i >= EL.length) return c.reply('Élément introuvable : ' + c.args[0]);
  const z = i + 1, period = [2, 10, 18, 36, 54, 86, 118].findIndex((x) => z <= x) + 1;
  await c.reply(U.box('Élément chimique', ['Nom : ' + EL[i], 'Symbole : ' + SY[i], 'Numéro atomique : ' + z, 'Période : ' + period]));
});
module.exports = { EL, SY, ddg, strip, dec };
